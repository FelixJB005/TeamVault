<?php
defined('TEAMVAULT') or exit;

// Encrypted storage ("encryption at rest").
// Everything in DATA_DIR is encrypted with the server's own key (AES-256-GCM), so a stolen copy of the
// data folder, or of a backup, is unreadable without SERVER_KEY_FILE.
// This is a second layer. Messages, descriptions and files are ALREADY encrypted in the browser with keys
// that the server never has. So even someone who owns the server and its key still cannot read them.

const SEAL_IV_BYTES = 12;
const SEAL_TAG_BYTES = 16;
const FILE_CHUNK_BYTES = 1048576;   // files are encrypted on the server in 1 MB pieces

/* ---------- The server key ---------- */

function server_key() {
    static $key = null;
    if ($key !== null) {
        return $key;
    }
    if (!function_exists('openssl_encrypt')) {
        throw new Exception('The PHP openssl extension is required.');
    }
    if (!is_file(SERVER_KEY_FILE)) {
        $folder = dirname(SERVER_KEY_FILE);
        if (!is_dir($folder)) {
            mkdir($folder, 0750, true);
        }
        $handle = @fopen(SERVER_KEY_FILE, 'x');          // 'x' fails if another request made it first
        if ($handle) {
            fwrite($handle, bin2hex(random_bytes(32)));
            fclose($handle);
            @chmod(SERVER_KEY_FILE, 0600);
        }
    }
    $key = hex2bin(trim((string) file_get_contents(SERVER_KEY_FILE)));
    if ($key === false || strlen($key) !== 32) {
        throw new Exception('The server key file is damaged.');
    }
    return $key;
}

// Encrypt text. $aad ties the result to its purpose, so one stored value cannot be swapped for another.
function seal($plain, $aad) {
    $iv = random_bytes(SEAL_IV_BYTES);
    $cipher = openssl_encrypt($plain, 'aes-256-gcm', server_key(), OPENSSL_RAW_DATA, $iv, $tag, $aad, SEAL_TAG_BYTES);
    if ($cipher === false) {
        throw new Exception('Encryption failed.');
    }
    return $iv . $tag . $cipher;
}

function unseal($blob, $aad) {
    if (strlen($blob) <= SEAL_IV_BYTES + SEAL_TAG_BYTES) {
        throw new Exception('Stored data is damaged.');
    }
    $iv = substr($blob, 0, SEAL_IV_BYTES);
    $tag = substr($blob, SEAL_IV_BYTES, SEAL_TAG_BYTES);
    $cipher = (string) substr($blob, SEAL_IV_BYTES + SEAL_TAG_BYTES);
    $plain = openssl_decrypt($cipher, 'aes-256-gcm', server_key(), OPENSSL_RAW_DATA, $iv, $tag, $aad);
    if ($plain === false) {
        throw new Exception('Stored data could not be decrypted (wrong server key, or the file is damaged).');
    }
    return $plain;
}

/* ---------- Data stores: users, communities, limits ---------- */

function store_path($name) {
    if (!is_dir(DATA_DIR)) {
        mkdir(DATA_DIR, 0750, true);
    }
    return DATA_DIR . '/' . $name . '.dat';
}

function decode_store($blob, $name) {
    if ($blob === '' || $blob === false) {
        return [];
    }
    $data = json_decode(unseal($blob, 'store:' . $name), true);
    return is_array($data) ? $data : [];
}

function store_read($name) {
    $path = store_path($name);
    if (!is_file($path)) {
        return [];
    }
    $handle = fopen($path, 'rb');
    flock($handle, LOCK_SH);
    $blob = stream_get_contents($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
    return decode_store($blob, $name);
}

// Read a store, let $change edit it, and save it. The file is locked meanwhile, so two requests at
// the same time cannot overwrite each other. If $change throws an error, nothing is saved.
function store_edit($name, callable $change) {
    $handle = fopen(store_path($name), 'c+');
    flock($handle, LOCK_EX);
    try {
        $data = decode_store(stream_get_contents($handle), $name);
        $result = $change($data);
        ftruncate($handle, 0);
        rewind($handle);
        fwrite($handle, seal(json_encode($data), 'store:' . $name));
        fflush($handle);
        return $result;
    } finally {
        flock($handle, LOCK_UN);
        fclose($handle);
    }
}

/* ---------- Files ---------- */
// The browser sends a file that is already encrypted. The server encrypts it once more, piece by piece, so
// even a 100 MB file never has to fit in memory.

function file_path($id) {
    return DATA_DIR . '/files/' . $id . '.bin';
}

function chunk_aad($id, $index, $isLast) {
    return 'file:' . $id . ':' . $index . ':' . ($isLast ? '1' : '0');
}

// Encrypt the uploaded temporary file into its place. Returns nothing, the file must not be empty.
function file_store($tempPath, $id) {
    if (!is_dir(DATA_DIR . '/files')) {
        mkdir(DATA_DIR . '/files', 0750, true);
    }
    $in = fopen($tempPath, 'rb');
    $out = fopen(file_path($id), 'wb');
    $index = 0;
    $current = (string) stream_get_contents($in, FILE_CHUNK_BYTES);
    while (true) {
        $next = (string) stream_get_contents($in, FILE_CHUNK_BYTES);
        $isLast = ($next === '');
        fwrite($out, seal($current, chunk_aad($id, $index, $isLast)));
        if ($isLast) {
            break;
        }
        $current = $next;
        $index++;
    }
    fclose($in);
    fclose($out);
}

// The decrypted pieces of a stored file, one at a time
function file_chunks($id) {
    $step = FILE_CHUNK_BYTES + SEAL_IV_BYTES + SEAL_TAG_BYTES;
    $count = (int) ceil(filesize(file_path($id)) / $step);
    $in = fopen(file_path($id), 'rb');
    for ($i = 0; $i < $count; $i++) {
        yield unseal((string) stream_get_contents($in, $step), chunk_aad($id, $i, $i === $count - 1));
    }
    fclose($in);
}

function file_plain_size($id) {
    $size = filesize(file_path($id));
    $count = (int) ceil($size / (FILE_CHUNK_BYTES + SEAL_IV_BYTES + SEAL_TAG_BYTES));
    return $size - $count * (SEAL_IV_BYTES + SEAL_TAG_BYTES);
}

function file_send($id) {
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . file_plain_size($id));
    foreach (file_chunks($id) as $chunk) { echo $chunk; }
    exit;
}

function file_remove($id) {
    if (is_file(file_path($id))) {
        unlink(file_path($id));
    }
}
