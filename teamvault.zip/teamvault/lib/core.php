<?php
defined('TEAMVAULT') or exit;

// Shared basics for auth.php and api.php:
// security headers, sessions, the anti-forgery token, JSON replies and errors, and the request router.

if (!function_exists('mb_strlen')) {
    function mb_strlen($text) { return preg_match_all('/./su', $text); }
}

ini_set('display_errors', DEBUG ? '1' : '0');

// An error with a message the user can read. It stops the request and nothing is saved.
class ApiError extends Exception {
    public $extra;
    public function __construct($message, $status = 200, $extra = []) {
        parent::__construct($message, $status);
        $this->extra = $extra;
    }
}

function reply(array $data) {
    echo json_encode($data);
    exit;
}

// Turn anything from the request into a trimmed string ('' if it is not text)
function text_of($value) {
    return is_string($value) ? trim($value) : '';
}

// Read a JSON field (for example a list of usernames) from the request
function json_field($value) {
    $data = is_string($value) ? json_decode($value, true) : null;
    return is_array($data) ? $data : [];
}

/* ---------- Where the request comes from ---------- */

function is_https() {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
}

function is_local() {
    $host = strtolower(preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? ''));
    return in_array($host, ['localhost', '127.0.0.1', '[::1]'], true);
}

// The address of the computer making the request. (Behind a proxy this is the proxy's address.)
function client_ip() {
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

/* ---------- Security ---------- */

function send_headers() {
    header('Content-Type: application/json');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: no-referrer');
    if (is_https()) {
        header('Strict-Transport-Security: max-age=31536000');
    }
}

function require_https() {
    if (FORCE_HTTPS && !is_https() && !is_local()) {
        throw new ApiError('This site must be opened with https:// so that your data is protected on the way.', 400);
    }
}

function start_session() {
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => is_https()]);
    session_name('teamvault');
    session_start();
}

// The anti-forgery token. The page sends it with every change, so other websites cannot make changes for you.
function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function check_csrf() {
    $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        throw new ApiError('Security check failed. Reload the page and try again.', 403, ['csrf' => true]);
    }
}

function current_user() {
    return $_SESSION['username'] ?? null;
}

/* ---------- The router ---------- */

// $routes: 'action' => [handler function name, 'GET' or 'POST', true if signing in is not needed]
// The action is always in the address (api.php?action=...), so it is known even when an upload is too big for PHP.
// A handler gets the signed in username and returns an array to send back, or throws an ApiError.
function dispatch(array $routes) {
    try {
        send_headers();
        require_https();
        start_session();

        $isPost = $_SERVER['REQUEST_METHOD'] === 'POST';
        $action = text_of($_GET['action'] ?? '');
        if (!isset($routes[$action])) {
            throw new ApiError('Invalid request.');
        }
        list($handler, $method, $public) = $routes[$action];
        if (($method === 'POST') !== $isPost) {
            throw new ApiError('Invalid request.');
        }

        // PHP throws away the whole body when it is bigger than post_max_size
        if ($isPost && empty($_POST) && empty($_FILES) && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
            throw new ApiError('The upload is bigger than the server allows. Raise upload_max_filesize and post_max_size in php.ini.');
        }
        if ($isPost) {
            check_csrf();
        }

        $me = current_user();
        if ($me === null && !$public) {
            throw new ApiError('Please sign in.', 401, ['signin' => true]);
        }
        $result = $handler($me);
        reply(array_merge(['ok' => true], $result ?: []));
    } catch (ApiError $e) {
        if ($e->getCode() >= 400) {
            http_response_code($e->getCode());
        }
        reply(array_merge(['ok' => false, 'error' => $e->getMessage()], $e->extra));
    } catch (Throwable $e) {
        error_log('TeamVault: ' . $e);
        http_response_code(500);
        reply(['ok' => false, 'error' => DEBUG ? $e->getMessage() : 'Something went wrong on the server.']);
    }
}
