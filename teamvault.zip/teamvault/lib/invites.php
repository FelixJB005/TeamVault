<?php
defined('TEAMVAULT') or exit;

// Invite links: an admin or sub-admin invites someone before they have an account.
//
// How the encryption works: the link looks like  login.html?invite=ID#SECRET
// The part after the # never leaves the browser. The inviter's browser locks the General channel keys with
// that SECRET and sends only the locked copy here. The new person's browser reads the SECRET from the link,
// unlocks the keys, and locks them again with their own public key. The server holds the invite but cannot open it.
// An invite works once, and only until it expires.

function new_invite_id() {
    return bin2hex(random_bytes(12));
}

// An invite that can still be used: not used up, not expired, and its creator can still invite people
function usable_invite(array $c, array $invite) {
    return $invite['expires'] > time() && can_manage($c, $invite['by']);
}

// Find an invite in any community: [community index, invite index] or null
function find_invite(array $all, $id) {
    foreach ($all as $i => $c) {
        foreach ($c['invites'] ?? [] as $n => $invite) {
            if ($invite['id'] === $id && usable_invite($c, $invite)) {
                return [$i, $n];
            }
        }
    }
    return null;
}

function act_create_invite($me) {
    $iv = text_of($_POST['iv'] ?? '');
    $ct = text_of($_POST['ct'] ?? '');
    if (strlen($iv) !== 16 || !is_b64($iv, 16) || !is_b64($ct, 6000)) {
        throw new ApiError('Invalid invite.');
    }
    $id = new_invite_id();
    $expires = time() + INVITE_DAYS * 86400;

    store_edit('communities', function (&$all) use ($me, $iv, $ct, $id, $expires) {
        $i = find_community($all, text_of($_POST['community'] ?? ''), $me);
        require_manager($all[$i], $me);
        $active = array_filter($all[$i]['invites'], function ($invite) { return $invite['expires'] > time(); });
        if (count($active) >= 50) {
            throw new ApiError('There are too many open invites. Revoke some first.');
        }
        $all[$i]['invites'] = array_values($active);
        $all[$i]['invites'][] = ['id' => $id, 'by' => $me, 'at' => time(), 'expires' => $expires, 'key_version' => $all[$i]['channels'][0]['key_version'], 'iv' => $iv, 'ct' => $ct];
        log_event($all[$i], 'invite_created', $me);
    });
    return ['invite' => $id, 'expires' => $expires];
}

function act_list_invites($me) {
    $all = store_read('communities');
    $c = $all[find_community($all, text_of($_GET['community'] ?? ''), $me)];
    require_manager($c, $me);
    $list = [];
    foreach ($c['invites'] as $invite) {
        if (usable_invite($c, $invite)) {
            $list[] = ['id' => $invite['id'], 'by' => $invite['by'], 'at' => $invite['at'], 'expires' => $invite['expires']];
        }
    }
    return ['invites' => $list];
}

function act_revoke_invite($me) {
    $id = text_of($_POST['invite'] ?? '');
    store_edit('communities', function (&$all) use ($me, $id) {
        $i = find_community($all, text_of($_POST['community'] ?? ''), $me);
        require_manager($all[$i], $me);
        $all[$i]['invites'] = array_values(array_filter($all[$i]['invites'], function ($invite) use ($id) { return $invite['id'] !== $id; }));
        log_event($all[$i], 'invite_revoked', $me);
    });
    return [];
}

// What the invited person's browser needs to show "Join X?" and to unlock the keys
function act_invite_info($me) {
    $all = store_read('communities');
    $found = find_invite($all, text_of($_GET['invite'] ?? ''));
    if ($found === null) {
        throw new ApiError('This invite link is not valid any more. Ask for a new one.');
    }
    list($i, $n) = $found;
    $c = $all[$i];
    $invite = $c['invites'][$n];
    if (member_role($c, $me) !== null) {
        return ['already_member' => true, 'community_id' => $c['id'], 'community' => $c['name']];
    }
    return ['community_id' => $c['id'], 'community' => $c['name'], 'by' => $invite['by'], 'expires' => $invite['expires'], 'iv' => $invite['iv'], 'ct' => $invite['ct']];
}

// Join with an invite. The browser sends the keys locked for the new member in "keys".
function act_accept_invite($me) {
    $id = text_of($_POST['invite'] ?? '');
    $communityId = store_edit('communities', function (&$all) use ($me, $id) {
        $found = find_invite($all, $id);
        if ($found === null) {
            throw new ApiError('This invite link is not valid any more. Ask for a new one.');
        }
        list($i, $n) = $found;
        $c = &$all[$i];
        if (member_role($c, $me) !== null) {
            throw new ApiError('You are already in this community.');
        }
        $by = $c['invites'][$n]['by'];
        $before = readers_map($c);
        $c['members'][] = ['user' => $me, 'role' => 'member'];
        enforce_keys($c, $before, json_field($_POST['keys'] ?? ''));
        array_splice($c['invites'], $n, 1);                  // one use only
        log_event($c, 'member_joined', $me, '', '', $by);
        return $c['id'];
    });
    return ['community_id' => $communityId];
}
