<?php
defined('TEAMVAULT') or exit;

// The rules of a community: roles, who can read what, and the key rules.
//
//   community = { id, name, members: [{user, role}], channels: [channel], invites: [], activity: [], created_at }
//   channel   = { id, name, type: 'general' | 'team', members: [picked people], key_version: 1,
//                 keys: { user: { v1: lockedKey, v2: lockedKey } },
//                 desc_iv, desc_ct, desc_kv, messages: [], files: [] }
//
// Roles:
//   admin     - everything: change roles, add and remove people, create and edit teams, reads every team.
//   subadmin  - adds people (as members), creates teams and edits the teams they are in.
//   member    - chats and shares files in the channels they can read.
// Everyone in a community reads the General channel. A team is read by its picked members and every admin.
// A person can be in as many teams as they like.

const ROLES = ['admin', 'subadmin', 'member'];

/* ---------- Finding things ---------- */

function community_index(array $all, $id) {
    foreach ($all as $i => $c) {
        if ($c['id'] === $id) {
            return $i;
        }
    }
    return -1;
}

function channel_index(array $community, $id) {
    foreach ($community['channels'] as $i => $channel) {
        if ($channel['id'] === $id) {
            return $i;
        }
    }
    return -1;
}

// A community that this user belongs to, or an error
function find_community(array $all, $id, $me) {
    $i = community_index($all, $id);
    if ($i < 0 || member_role($all[$i], $me) === null) {
        throw new ApiError('Community not found.');
    }
    return $i;
}

/* ---------- People and roles ---------- */

function member_names(array $community) {
    return array_map(function ($m) { return $m['user']; }, $community['members']);
}

function member_role(array $community, $user) {
    foreach ($community['members'] as $m) {
        if ($m['user'] === $user) {
            return $m['role'];
        }
    }
    return null;
}

function admin_names(array $community) {
    $admins = array_filter($community['members'], function ($m) { return $m['role'] === 'admin'; });
    return array_values(array_map(function ($m) { return $m['user']; }, $admins));
}

function can_manage(array $community, $user) {
    return in_array(member_role($community, $user), ['admin', 'subadmin'], true);
}

function require_admin(array $community, $me) {
    if (member_role($community, $me) !== 'admin') {
        throw new ApiError('Only admins can do that.');
    }
}

function require_manager(array $community, $me) {
    if (!can_manage($community, $me)) {
        throw new ApiError('Only admins and sub-admins can do that.');
    }
}

/* ---------- Who can read a channel ---------- */

// The picked people of a team who are still members of the community
function team_people(array $community, array $channel) {
    return array_values(array_intersect($channel['members'], member_names($community)));
}

function channel_readers(array $community, array $channel) {
    if ($channel['type'] === 'general') {
        return member_names($community);
    }
    return array_values(array_unique(array_merge(team_people($community, $channel), admin_names($community))));
}

// Index of a channel this user can read, or an error
function readable_channel(array $community, $channelId, $me) {
    $k = channel_index($community, $channelId);
    if ($k < 0 || !in_array($me, channel_readers($community, $community['channels'][$k]), true)) {
        throw new ApiError('Chat not found.');
    }
    return $k;
}

// channel id => readers. Taken before a change, so the changes can be compared afterwards.
function readers_map(array $community) {
    $map = [];
    foreach ($community['channels'] as $channel) {
        $map[$channel['id']] = channel_readers($community, $channel);
    }
    return $map;
}

/* ---------- Reading the request ---------- */

function is_b64($text, $maxLength) {
    return is_string($text) && $text !== '' && strlen($text) <= $maxLength && preg_match('/^[A-Za-z0-9+\/=]+$/', $text) === 1;
}

// Keep only the usernames from a list that are in $allowed
function clean_names($value, array $allowed) {
    $list = array_filter(json_field($value), 'is_string');
    return array_values(array_unique(array_intersect($list, $allowed)));
}

// { username: { v1: lockedKey } } -> the same, with everything checked. Only $allowed usernames are kept.
function clean_key_map($map, array $allowed) {
    $clean = [];
    foreach (is_array($map) ? $map : [] as $user => $versions) {
        $user = (string) $user;
        if (!in_array($user, $allowed, true) || !is_array($versions)) {
            continue;
        }
        foreach ($versions as $name => $locked) {
            if (preg_match('/^v[1-9][0-9]{0,3}$/', (string) $name) === 1 && is_b64($locked, 1000)) {
                $clean[$user][(string) $name] = $locked;
            }
        }
    }
    return $clean;
}

/* ---------- The key rules ---------- */

// Run after any change of who can read what.
//  - If somebody lost access to a channel, the channel gets a new key version.
//  - The locked keys sent with the request are added.
//  - Then every reader must have a locked key for every version, otherwise the whole change is refused.
// $before: readers_map() from before the change. $payload: channel id => { user: { v1: locked } }.
// Returns true if the General channel got a new key version (invite links made earlier no longer work).
function enforce_keys(array &$community, array $before, array $payload) {
    $generalRotated = false;
    foreach ($community['channels'] as &$channel) {
        $after = channel_readers($community, $channel);
        $old = $before[$channel['id']] ?? null;                       // null for a brand new channel
        if ($old !== null && count(array_diff($old, $after)) > 0) {
            $channel['key_version']++;
            $generalRotated = $generalRotated || $channel['type'] === 'general';
        }

        // keep the locked keys of the readers, add the new ones, drop everybody else's
        $keys = [];
        foreach ($after as $user) {
            $keys[$user] = $channel['keys'][$user] ?? [];
        }
        foreach (clean_key_map($payload[$channel['id']] ?? [], $after) as $user => $versions) {
            foreach ($versions as $name => $locked) {
                $keys[$user][$name] = $locked;
            }
        }
        foreach ($after as $user) {
            for ($v = 1; $v <= $channel['key_version']; $v++) {
                if (empty($keys[$user]['v' . $v])) {
                    throw new ApiError('Encryption keys are missing. Reload the page and try again.');
                }
            }
        }
        $channel['keys'] = $keys;
    }
    unset($channel);
    return $generalRotated;
}

// Is this key version one that exists? Used for messages, files and descriptions.
function valid_version($value, array $channel) {
    $version = (int) $value;
    if ($version < 1 || $version > $channel['key_version']) {
        throw new ApiError('Invalid encryption key version.');
    }
    return $version;
}

/* ---------- What the page gets to see ---------- */

// Only the channels this user can read, without messages and files
function view_of(array $community, $me) {
    $channels = [];
    foreach ($community['channels'] as $channel) {
        $readers = channel_readers($community, $channel);
        if (in_array($me, $readers, true)) {
            $channels[] = [
                'id'          => $channel['id'],
                'name'        => $channel['name'],
                'type'        => $channel['type'],
                'members'     => $readers,
                'explicit'    => $channel['type'] === 'team' ? team_people($community, $channel) : [],
                'key_version' => $channel['key_version'],
                'keys'        => (object) ($channel['keys'][$me] ?? []),   // this user's locked copies of each key version
                'desc_iv'     => $channel['desc_iv'] ?? '',
                'desc_ct'     => $channel['desc_ct'] ?? '',
                'desc_kv'     => $channel['desc_kv'] ?? 1,
            ];
        }
    }
    return [
        'id'       => $community['id'],
        'name'     => $community['name'],
        'role'     => member_role($community, $me),
        'members'  => $community['members'],
        'channels' => $channels,
    ];
}

/* ---------- Activity log (who did what, never what was written) ---------- */

function log_event(array &$community, $kind, $actor, $subject = '', $channel = '', $detail = '') {
    $community['activity'][] = ['at' => time(), 'kind' => $kind, 'actor' => $actor, 'subject' => $subject, 'channel' => $channel, 'detail' => $detail];
    if (count($community['activity']) > 300) {
        $community['activity'] = array_slice($community['activity'], -300);
    }
}

function new_channel($id, $name, $type, array $picked, array $keys) {
    return [
        'id' => $id, 'name' => $name, 'type' => $type, 'members' => $picked,
        'key_version' => 1, 'keys' => $keys, 'desc_iv' => '', 'desc_ct' => '', 'desc_kv' => 1,
        'messages' => [], 'files' => [],
    ];
}
