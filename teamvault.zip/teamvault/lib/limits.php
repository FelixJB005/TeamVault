<?php
defined('TEAMVAULT') or exit;

// Limits on wrong passwords and recovery codes. After too many failures the username (or computer) is
// locked for a while. What is stored is a hash, not the username or address itself.

function limit_id($bucket, $key) {
    return hash('sha256', $bucket . ':' . strtolower($key));
}

// Stop the request if this username/address is locked
function limit_check($bucket, $key) {
    $row = store_read('limits')[limit_id($bucket, $key)] ?? null;
    if ($row && $row['until'] > time()) {
        $minutes = (int) ceil(($row['until'] - time()) / 60);
        throw new ApiError('Too many attempts. Try again in ' . $minutes . ' minute' . ($minutes === 1 ? '' : 's') . '.', 429);
    }
}

// Count one failure. At $max failures within the time window the lock starts.
function limit_fail($bucket, $key, $max) {
    $id = limit_id($bucket, $key);
    $window = LOGIN_WINDOW_MINUTES * 60;
    store_edit('limits', function (&$rows) use ($id, $max, $window) {
        $now = time();
        foreach ($rows as $other => $row) {            // forget old entries
            if ($row['until'] < $now && $row['first'] < $now - $window) {
                unset($rows[$other]);
            }
        }
        $row = $rows[$id] ?? ['count' => 0, 'first' => $now, 'until' => 0];
        if ($row['first'] < $now - $window) {
            $row = ['count' => 0, 'first' => $now, 'until' => 0];
        }
        $row['count']++;
        if ($row['count'] >= $max) {
            $row = ['count' => 0, 'first' => $now, 'until' => $now + LOGIN_LOCK_MINUTES * 60];
        }
        $rows[$id] = $row;
    });
}

function limit_clear($bucket, $key) {
    $id = limit_id($bucket, $key);
    store_edit('limits', function (&$rows) use ($id) {
        unset($rows[$id]);
    });
}

// Failures from one username, and from one computer (which gets a higher limit, because many people can share one)
function limit_check_login($username) {
    limit_check('user', $username);
    limit_check('ip', client_ip());
}

function limit_fail_login($username) {
    limit_fail('user', $username, LOGIN_MAX_FAILS);
    limit_fail('ip', client_ip(), LOGIN_MAX_FAILS * 5);
}
