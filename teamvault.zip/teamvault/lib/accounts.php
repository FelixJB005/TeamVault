<?php
defined('TEAMVAULT') or exit;

// Accounts: register, sign in, sign out, change password, recovery code.
//
// The browser never sends the real password. It sends a "login secret" made from the password, and the
// server stores a hash of that secret. Each user also has an RSA key pair: the public key is stored as it is,
// the private key is stored locked with the password (and a second copy locked with the recovery code).
// That is why the server cannot read anyone's data, and why a forgotten password needs the recovery code.

function find_user($username) {
    foreach (store_read('users') as $user) {
        if (strcasecmp($user['username'], $username) === 0) {
            return $user;
        }
    }
    return null;
}

function usernames() {
    return array_map(function ($user) { return $user['username']; }, store_read('users'));
}

function update_user($username, array $changes) {
    store_edit('users', function (&$users) use ($username, $changes) {
        foreach ($users as &$user) {
            if (strcasecmp($user['username'], $username) === 0) {
                $user = array_merge($user, $changes);
            }
        }
        unset($user);
    });
}

function is_hex64($value) {
    return is_string($value) && preg_match('/^[0-9a-f]{64}$/', $value) === 1;
}

// A locked key made by the browser: a JSON text of a sensible size
function is_sealed_json($value, $maxLength) {
    return is_string($value) && strlen($value) <= $maxLength && is_array(json_decode($value, true));
}

// A hash to compare against when the user does not exist, so timing does not reveal valid usernames
function dummy_hash() {
    static $hash = null;
    if ($hash === null) {
        $hash = password_hash('dummy', PASSWORD_DEFAULT);
    }
    return $hash;
}

// Check the current password (for changing it). Too many mistakes lock the account for a while.
function verify_password($username, $secret) {
    limit_check_login($username);
    $user = find_user($username);
    if (!$user || !is_hex64($secret) || !password_verify($secret, $user['password'])) {
        limit_fail_login($username);
        throw new ApiError('Your current password is not correct.');
    }
    limit_clear('user', $username);
    return $user;
}

// Check a recovery proof (made from the recovery code)
function verify_recovery($username, $proof) {
    limit_check_login($username);
    $user = find_user($username);
    $hash = ($user && !empty($user['recovery_hash'])) ? $user['recovery_hash'] : dummy_hash();
    if (!$user || !is_hex64($proof) || !password_verify($proof, $hash)) {
        limit_fail_login($username);
        throw new ApiError('The username or the recovery code is not correct.');
    }
    limit_clear('user', $username);
    return $user;
}

/* ---------- Actions ---------- */

// Who is signed in, plus the anti-forgery token the page must send with every change
function act_me($me) {
    return ['username' => $me, 'csrf' => csrf_token()];
}

function act_register($me) {
    limit_check('register', client_ip());

    $username = text_of($_POST['username'] ?? '');
    $email = text_of($_POST['email'] ?? '');
    $secret = text_of($_POST['password'] ?? '');
    $publicKey = text_of($_POST['public_key'] ?? '');
    $wrappedKey = text_of($_POST['wrapped_private_key'] ?? '');
    $recoveryProof = text_of($_POST['recovery_proof'] ?? '');
    $recoveryKey = text_of($_POST['recovery_private_key'] ?? '');

    if ($username === '' || mb_strlen($username) > 50) {
        throw new ApiError('Username must be 1-50 characters.');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new ApiError('Enter a valid email address.');
    }
    // The password rules (at least 8 characters) are checked in the browser, because the server only gets the login secret.
    if (!is_hex64($secret) || !is_hex64($recoveryProof)) {
        throw new ApiError('Invalid request.');
    }
    if (!is_sealed_json($publicKey, 2000) || !is_sealed_json($wrappedKey, 10000) || !is_sealed_json($recoveryKey, 10000)) {
        throw new ApiError('Invalid encryption keys.');
    }

    limit_fail('register', client_ip(), 10);        // at most 10 new accounts per 15 minutes from one computer
    store_edit('users', function (&$users) use ($username, $email, $secret, $publicKey, $wrappedKey, $recoveryProof, $recoveryKey) {
        foreach ($users as $user) {
            if (strcasecmp($user['username'], $username) === 0 || strcasecmp($user['email'], $email) === 0) {
                throw new ApiError('That username or email is already registered.');
            }
        }
        $users[] = [
            'id'                           => count($users) + 1,
            'username'                     => $username,
            'email'                        => $email,
            'password'                     => password_hash($secret, PASSWORD_DEFAULT),
            'public_key'                   => $publicKey,
            'wrapped_private_key'          => $wrappedKey,
            'recovery_hash'                => password_hash($recoveryProof, PASSWORD_DEFAULT),
            'recovery_wrapped_private_key' => $recoveryKey,
            'created_at'                   => date('c'),
        ];
    });
    return [];
}

function act_login($me) {
    $username = text_of($_POST['username'] ?? '');
    $secret = text_of($_POST['password'] ?? '');
    limit_check_login($username);

    $user = find_user($username);
    $hash = $user ? $user['password'] : dummy_hash();
    if (!$user || !is_hex64($secret) || !password_verify($secret, $hash)) {
        limit_fail_login($username);
        throw new ApiError('Incorrect username or password.');
    }
    limit_clear('user', $username);

    session_regenerate_id(true);
    $_SESSION['username'] = $user['username'];
    unset($_SESSION['csrf']);                        // a new anti-forgery token for the new session
    return ['username' => $user['username'], 'wrapped_private_key' => $user['wrapped_private_key'], 'csrf' => csrf_token()];
}

function act_logout($me) {
    $_SESSION = [];
    session_destroy();
    return [];
}

function act_change_password($me) {
    verify_password($me, text_of($_POST['current'] ?? ''));
    $new = text_of($_POST['new'] ?? '');
    $wrappedKey = text_of($_POST['wrapped_private_key'] ?? '');
    if (!is_hex64($new) || !is_sealed_json($wrappedKey, 10000)) {
        throw new ApiError('Invalid request.');
    }
    update_user($me, ['password' => password_hash($new, PASSWORD_DEFAULT), 'wrapped_private_key' => $wrappedKey]);
    return [];
}

function act_new_recovery($me) {
    verify_password($me, text_of($_POST['current'] ?? ''));
    $proof = text_of($_POST['recovery_proof'] ?? '');
    $recoveryKey = text_of($_POST['recovery_private_key'] ?? '');
    if (!is_hex64($proof) || !is_sealed_json($recoveryKey, 10000)) {
        throw new ApiError('Invalid request.');
    }
    update_user($me, ['recovery_hash' => password_hash($proof, PASSWORD_DEFAULT), 'recovery_wrapped_private_key' => $recoveryKey]);
    return [];
}

// Forgot password, step 1: the browser proves it has the recovery code and gets the locked private key back
function act_recovery_start($me) {
    $user = verify_recovery(text_of($_POST['username'] ?? ''), text_of($_POST['recovery_proof'] ?? ''));
    return ['recovery_private_key' => $user['recovery_wrapped_private_key']];
}

// Forgot password, step 2: the browser unlocked the private key with the recovery code and locked it again with a new password
function act_recovery_finish($me) {
    $username = text_of($_POST['username'] ?? '');
    $user = verify_recovery($username, text_of($_POST['recovery_proof'] ?? ''));
    $new = text_of($_POST['new'] ?? '');
    $wrappedKey = text_of($_POST['wrapped_private_key'] ?? '');
    if (!is_hex64($new) || !is_sealed_json($wrappedKey, 10000)) {
        throw new ApiError('Invalid request.');
    }
    update_user($user['username'], ['password' => password_hash($new, PASSWORD_DEFAULT), 'wrapped_private_key' => $wrappedKey]);
    return [];
}
