<?php
defined('TEAMVAULT') or exit;

// Communities: people, roles, teams, the overview page and the activity log.
// The rules for roles and keys are in community.php.

function users_list() {
    $list = array_map(function ($u) { return ['username' => $u['username'], 'public_key' => $u['public_key'] ?? '']; }, store_read('users'));
    usort($list, function ($a, $b) { return strcasecmp($a['username'], $b['username']); });
    return $list;
}

function communities_of($me, array $all) {
    $mine = [];
    foreach ($all as $c) {
        if (member_role($c, $me) !== null) {
            $mine[] = view_of($c, $me);
        }
    }
    return $mine;
}

function act_users($me) {
    return ['users' => users_list()];
}

function act_communities($me) {
    return ['communities' => communities_of($me, store_read('communities'))];
}

// Everything the page needs in one request, so it only has to ask the server once every few seconds:
// the people, the communities, and (for the open channel) the new messages and the file list.
function act_sync($me) {
    $all = store_read('communities');
    $result = ['users' => users_list(), 'communities' => communities_of($me, $all), 'messages' => null, 'files' => null];

    $i = community_index($all, text_of($_GET['community'] ?? ''));
    if ($i >= 0 && member_role($all[$i], $me) !== null) {
        $k = channel_index($all[$i], text_of($_GET['channel'] ?? ''));
        if ($k >= 0 && in_array($me, channel_readers($all[$i], $all[$i]['channels'][$k]), true)) {
            $result['messages'] = messages_after($all[$i]['channels'][$k], (int) ($_GET['after'] ?? 0));
            if (($_GET['files'] ?? '') === '1') {
                $result['files'] = $all[$i]['channels'][$k]['files'];
            }
        }
    }
    return $result;
}

/* ---------- Changing a community ---------- */

// Run a change to one community. Afterwards the key rules are enforced: the whole change is refused
// if somebody would miss a key. $finish (optional) runs after that and can still refuse the change.
function change_community($me, callable $change, ?callable $finish = null) {
    $id = text_of($_POST['community'] ?? '');
    return store_edit('communities', function (&$all) use ($me, $id, $change, $finish) {
        $i = find_community($all, $id, $me);
        $c = &$all[$i];
        $before = readers_map($c);
        $result = $change($c);
        $rotated = enforce_keys($c, $before, json_field($_POST['keys'] ?? ''));
        if ($rotated && !empty($c['invites'])) {
            $c['invites'] = [];                        // invite links hold the old General key, so they stop working
            log_event($c, 'invites_cleared', $me);
        }
        if ($finish) {
            $finish($c, $result);
        }
        return $result;
    });
}

function act_create_community($me) {
    $name = text_of($_POST['name'] ?? '');
    if ($name === '' || mb_strlen($name) > 40) {
        throw new ApiError('Community name must be 1-40 characters.');
    }

    // The creator is an admin. The people they add can be admins, sub-admins or members.
    $roles = json_field($_POST['roles'] ?? '');
    $members = [['user' => $me, 'role' => 'admin']];
    foreach (clean_names($_POST['members'] ?? '', usernames()) as $user) {
        if ($user !== $me) {
            $role = $roles[$user] ?? 'member';
            $members[] = ['user' => $user, 'role' => in_array($role, ROLES, true) ? $role : 'member'];
        }
    }
    $community = [
        'id'         => bin2hex(random_bytes(6)),
        'name'       => $name,
        'members'    => $members,
        'channels'   => [new_channel('general', 'General', 'general', [], [])],
        'invites'    => [],
        'activity'   => [],
        'created_at' => time(),
    ];
    enforce_keys($community, [], json_field($_POST['keys'] ?? ''));
    log_event($community, 'community_created', $me);
    store_edit('communities', function (&$all) use ($community) {
        $all[] = $community;
    });
    return ['community' => view_of($community, $me)];
}

// Admins and sub-admins add people. Sub-admins can only add members. Admins can add members and sub-admins.
// Making someone an admin is a separate step (set_role) because it needs the keys of every team.
function act_add_members($me) {
    change_community($me, function (&$c) use ($me) {
        require_manager($c, $me);
        $roles = json_field($_POST['roles'] ?? '');
        $new = array_values(array_diff(clean_names($_POST['members'] ?? '', usernames()), member_names($c)));
        foreach ($new as $user) {
            $role = (member_role($c, $me) === 'admin' && ($roles[$user] ?? '') === 'subadmin') ? 'subadmin' : 'member';
            $c['members'][] = ['user' => $user, 'role' => $role];
            log_event($c, 'member_added', $me, $user, '', $role);
        }
    });
    return [];
}

// Only admins change roles. A new admin gets the keys of every team. When somebody stops being an admin,
// the teams they were not picked for get a new key.
function act_set_role($me) {
    change_community($me, function (&$c) use ($me) {
        require_admin($c, $me);
        $user = text_of($_POST['user'] ?? '');
        $role = text_of($_POST['role'] ?? '');
        $was = member_role($c, $user);
        if (!in_array($role, ROLES, true) || $was === null) {
            throw new ApiError('Invalid request.');
        }
        if ($was === 'admin' && $role !== 'admin' && count(admin_names($c)) === 1) {
            throw new ApiError('A community needs at least one admin.');
        }
        foreach ($c['members'] as &$member) {
            if ($member['user'] === $user) {
                $member['role'] = $role;
            }
        }
        unset($member);
        if ($was !== $role) {
            log_event($c, 'role_changed', $me, $user, '', $role);
        }
    });
    return [];
}

// Remove somebody from the community and from every team. Every channel they could read gets a new key.
function act_remove_member($me) {
    change_community($me, function (&$c) use ($me) {
        require_admin($c, $me);
        $user = text_of($_POST['user'] ?? '');
        if ($user === $me) {
            throw new ApiError('You cannot remove yourself. Ask another admin to do it.');
        }
        if (member_role($c, $user) === null) {
            throw new ApiError('That person is not in this community.');
        }
        $c['members'] = array_values(array_filter($c['members'], function ($m) use ($user) { return $m['user'] !== $user; }));
        foreach ($c['channels'] as &$channel) {
            $channel['members'] = array_values(array_diff($channel['members'], [$user]));
        }
        unset($channel);
        log_event($c, 'member_removed', $me, $user);
    });
    return [];
}

/* ---------- Teams ---------- */

function team_name() {
    $name = text_of($_POST['name'] ?? '');
    if ($name === '' || mb_strlen($name) > 40) {
        throw new ApiError('Team name must be 1-40 characters.');
    }
    return $name;
}

// The picked people of a team. A sub-admin is always part of the teams they create or edit.
function team_picks(array $c, $me) {
    $picked = clean_names($_POST['members'] ?? '', member_names($c));
    if (member_role($c, $me) === 'subadmin' && !in_array($me, $picked, true)) {
        $picked[] = $me;
    }
    return $picked;
}

// The description is encrypted in the browser. Both parts are empty when there is no description.
function apply_description(array &$channel) {
    $iv = text_of($_POST['desc_iv'] ?? '');
    $ct = text_of($_POST['desc_ct'] ?? '');
    if ($iv === '' && $ct === '') {
        $channel['desc_iv'] = '';
        $channel['desc_ct'] = '';
        $channel['desc_kv'] = 1;
        return;
    }
    if (strlen($iv) !== 16 || !is_b64($iv, 16) || !is_b64($ct, 4000)) {
        throw new ApiError('Invalid description.');
    }
    $channel['desc_iv'] = $iv;
    $channel['desc_ct'] = $ct;
    $channel['desc_kv'] = valid_version($_POST['desc_kv'] ?? 0, $channel);
}

// The browser makes the team id, so it can lock the first key for it in the same request
function act_create_team($me) {
    $id = text_of($_POST['channel'] ?? '');
    $result = change_community($me, function (&$c) use ($me, $id) {
        require_manager($c, $me);
        if (preg_match('/^[a-f0-9]{12}$/', $id) !== 1 || channel_index($c, $id) >= 0) {
            throw new ApiError('Invalid team id.');
        }
        $name = team_name();
        $c['channels'][] = new_channel($id, $name, 'team', team_picks($c, $me), []);
        log_event($c, 'team_created', $me, '', $name);
    }, function (&$c) use ($id) {
        apply_description($c['channels'][channel_index($c, $id)]);
    });
    return ['channel' => $id];
}

// Editing a team: name, description, people. If somebody loses access the team gets a new key.
function act_update_team($me) {
    $id = text_of($_POST['channel'] ?? '');
    change_community($me, function (&$c) use ($me, $id) {
        require_manager($c, $me);
        $k = readable_channel($c, $id, $me);
        if ($c['channels'][$k]['type'] !== 'team') {
            throw new ApiError('Team not found.');
        }
        $old = team_people($c, $c['channels'][$k]);
        $picked = team_picks($c, $me);
        $c['channels'][$k]['name'] = team_name();
        $c['channels'][$k]['members'] = $picked;
        $name = $c['channels'][$k]['name'];
        log_event($c, 'team_updated', $me, '', $name);
        foreach (array_diff($picked, $old) as $user) {
            log_event($c, 'team_member_added', $me, $user, $name);
        }
        foreach (array_diff($old, $picked) as $user) {
            log_event($c, 'team_member_removed', $me, $user, $name);
        }
    }, function (&$c) use ($id) {
        apply_description($c['channels'][channel_index($c, $id)]);
    });
    return ['channel' => $id];
}

/* ---------- Overview and activity log ---------- */

// Numbers and the newest files for the Overview page. File names are still encrypted.
function act_overview($me) {
    $all = store_read('communities');
    $c = $all[find_community($all, text_of($_GET['community'] ?? ''), $me)];

    $stats = ['members' => count($c['members']), 'teams' => 0, 'files' => 0, 'bytes' => 0, 'messages' => 0];
    $recent = [];
    foreach ($c['channels'] as $channel) {
        if (!in_array($me, channel_readers($c, $channel), true)) {
            continue;
        }
        $stats['teams'] += $channel['type'] === 'team' ? 1 : 0;
        $stats['messages'] += count($channel['messages']);
        foreach ($channel['files'] as $file) {
            $stats['files']++;
            $stats['bytes'] += $file['size'];
            $recent[] = array_merge($file, ['channel' => $channel['id'], 'channel_name' => $channel['name']]);
        }
    }
    usort($recent, function ($a, $b) { return $b['at'] - $a['at']; });
    return ['stats' => $stats, 'recent_files' => array_slice($recent, 0, 6)];
}

// Who did what and when. Only admins see this. It never contains message text or file names.
function act_activity($me) {
    $all = store_read('communities');
    $c = $all[find_community($all, text_of($_GET['community'] ?? ''), $me)];
    require_admin($c, $me);
    return ['events' => array_reverse(array_slice($c['activity'], -100))];
}
