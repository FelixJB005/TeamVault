<?php
defined('TEAMVAULT') or exit;

// Messages and files. Both arrive already encrypted by the browser. The server stores them,
// checks that the sender is allowed to be in the channel, and never sees what is inside.

function messages_after(array $channel, $after) {
    return array_values(array_filter($channel['messages'], function ($m) use ($after) { return $m['id'] > $after; }));
}

function act_messages($me) {
    $all = store_read('communities');
    $i = find_community($all, text_of($_GET['community'] ?? ''), $me);
    $k = readable_channel($all[$i], text_of($_GET['channel'] ?? ''), $me);
    return ['messages' => messages_after($all[$i]['channels'][$k], (int) ($_GET['after'] ?? 0))];
}

function act_send_message($me) {
    $iv = text_of($_POST['iv'] ?? '');
    $ct = text_of($_POST['ct'] ?? '');
    if (strlen($iv) !== 16 || !is_b64($iv, 16) || !is_b64($ct, 8000)) {
        throw new ApiError('Invalid message.');
    }
    $community = text_of($_POST['community'] ?? '');
    $channelId = text_of($_POST['channel'] ?? '');

    store_edit('communities', function (&$all) use ($me, $community, $channelId, $iv, $ct) {
        $i = find_community($all, $community, $me);
        $k = readable_channel($all[$i], $channelId, $me);
        $channel = &$all[$i]['channels'][$k];
        $channel['messages'][] = [
            'id'   => count($channel['messages']) + 1,
            'user' => $me,
            'at'   => time(),
            'kv'   => valid_version($_POST['kv'] ?? 0, $channel),     // which key version encrypted it
            'iv'   => $iv,
            'ct'   => $ct,
        ];
    });
    return [];
}

function act_files($me) {
    $all = store_read('communities');
    $i = find_community($all, text_of($_GET['community'] ?? ''), $me);
    $k = readable_channel($all[$i], text_of($_GET['channel'] ?? ''), $me);
    return ['files' => array_values($all[$i]['channels'][$k]['files'])];
}

// Save an encrypted file. The file name is encrypted too (name_iv, name_ct).
function act_upload_file($me) {
    $community = text_of($_POST['community'] ?? '');
    $channelId = text_of($_POST['channel'] ?? '');
    $iv = text_of($_POST['iv'] ?? '');
    $nameIv = text_of($_POST['name_iv'] ?? '');
    $nameCt = text_of($_POST['name_ct'] ?? '');
    // iv is the 8 byte start of the chunk IVs (12 characters). name_iv is a normal 12 byte IV (16 characters).
    if (strlen($iv) !== 12 || !is_b64($iv, 12) || strlen($nameIv) !== 16 || !is_b64($nameIv, 16) || !is_b64($nameCt, 2000)) {
        throw new ApiError('Invalid file.');
    }

    $upload = $_FILES['blob'] ?? null;
    if (!$upload || $upload['error'] !== UPLOAD_ERR_OK) {
        throw new ApiError('Upload failed. The file may be too large for the server.');
    }
    if ($upload['size'] > MAX_FILE_BYTES) {
        throw new ApiError('Files can be at most ' . MAX_FILE_MB . ' MB.');
    }
    if ($upload['size'] < 16) {
        throw new ApiError('Invalid file.');
    }

    // Check access before saving anything
    $all = store_read('communities');
    $i = find_community($all, $community, $me);
    $k = readable_channel($all[$i], $channelId, $me);
    $kv = valid_version($_POST['kv'] ?? 0, $all[$i]['channels'][$k]);

    $fileId = bin2hex(random_bytes(6));
    file_store($upload['tmp_name'], $fileId);                    // encrypted once more on the server
    $size = $upload['size'];
    try {
        store_edit('communities', function (&$all) use ($me, $community, $channelId, $fileId, $kv, $iv, $nameIv, $nameCt, $size) {
            $i = find_community($all, $community, $me);
            $k = readable_channel($all[$i], $channelId, $me);
            $all[$i]['channels'][$k]['files'][] = ['id' => $fileId, 'user' => $me, 'at' => time(), 'kv' => $kv, 'iv' => $iv, 'name_iv' => $nameIv, 'name_ct' => $nameCt, 'size' => $size];
            log_event($all[$i], 'file_uploaded', $me, '', $all[$i]['channels'][$k]['name'], (string) $size);
        });
    } catch (Throwable $e) {
        file_remove($fileId);
        throw $e;
    }
    return [];
}

// Send one file. It is decrypted on the server (the server layer only), and the browser decrypts the rest.
function act_download_file($me) {
    $all = store_read('communities');
    $i = find_community($all, text_of($_GET['community'] ?? ''), $me);
    $k = readable_channel($all[$i], text_of($_GET['channel'] ?? ''), $me);
    $fileId = text_of($_GET['file'] ?? '');
    foreach ($all[$i]['channels'][$k]['files'] as $file) {
        if ($file['id'] === $fileId && is_file(file_path($fileId))) {
            file_send($fileId);
        }
    }
    throw new ApiError('File not found.');
}

// Only the person who uploaded a file, an admin or a sub-admin can delete it
function act_delete_file($me) {
    $community = text_of($_POST['community'] ?? '');
    $channelId = text_of($_POST['channel'] ?? '');
    $fileId = text_of($_POST['file'] ?? '');

    store_edit('communities', function (&$all) use ($me, $community, $channelId, $fileId) {
        $i = find_community($all, $community, $me);
        $k = readable_channel($all[$i], $channelId, $me);
        foreach ($all[$i]['channels'][$k]['files'] as $n => $file) {
            if ($file['id'] === $fileId) {
                if ($file['user'] !== $me && !can_manage($all[$i], $me)) {
                    throw new ApiError('You cannot delete this file.');
                }
                array_splice($all[$i]['channels'][$k]['files'], $n, 1);
                log_event($all[$i], 'file_deleted', $me, $file['user'], $all[$i]['channels'][$k]['name']);
                return;
            }
        }
        throw new ApiError('File not found.');
    });
    if (preg_match('/^[a-f0-9]{12}$/', $fileId) === 1) {
        file_remove($fileId);
    }
    return [];
}
