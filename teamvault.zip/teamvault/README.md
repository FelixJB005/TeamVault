# TeamVault

A private workspace for teams. Messages, team descriptions, file names and files are encrypted in the
browser with keys the server never has. The server stores only unreadable data, and encrypts it once
more with its own key.

---

## 1. File structure of the project

```
Teamvault/
├── login.html            Sign in, create account, recovery code, forgot password, invite links
├── main.html             The workspace (Overview, Chat, Files, Members, Activity)
├── auth.php              Accounts API: lists the actions, the work is in lib/accounts.php
├── api.php               Workspace API: lists the actions, the work is in lib/
├── config.php            The only PHP file you edit for hosting (data folder, limits)
├── check.php             Setup check page. Open once, then DELETE it
├── htaccess.txt          Rename to .htaccess on an Apache server (https, headers, upload limits)
│
├── lib/                  The server code, one file per job
│   ├── core.php          Security headers, sessions, anti-forgery token, router, errors
│   ├── store.php         Encrypted storage: data stores and files
│   ├── limits.php        Locks usernames and addresses after too many wrong passwords
│   ├── accounts.php      Register, sign in, password, recovery
│   ├── community.php     Roles, who can read what, the key rules, the activity log
│   ├── workspace.php     Communities, people, teams, overview, activity
│   ├── chat.php          Messages and files
│   └── invites.php       Invite links
│
├── js/                   The browser code
│   ├── theme.js          Light / dark mode
│   ├── crypto.js         All encryption (Web Crypto API)
│   ├── keys.js           The key rules: who needs which key after a change
│   ├── api.js            Talking to the server (adds the anti-forgery token)
│   ├── login.js          The sign in page
│   ├── state.js          Shared state and helpers of the workspace page
│   ├── layout.js         Sidebar, tabs, opening a community or channel
│   ├── chat.js           Messages
│   ├── files.js          Files
│   ├── people.js         Members, teams, invite links
│   ├── overview.js       Overview and activity log
│   ├── dialogs.js        Dialogs and Settings
│   └── main.js           Starting up and asking the server for news
│
├── css/
│   ├── theme.css         Colors (light and dark) and basic parts
│   ├── login.css         The sign in page
│   └── main.css          The workspace, including the phone layout
│
├── Images/logo/          teamvault-logo-stack5.svg  (your logo)
└── data/                 Where everything is stored (see section 3). Better: move it outside the web folder
```

How the work is split:

```
  BROWSER (holds all keys)                         SERVER (PHP)
  ─────────────────────────                        ────────────────────────────
  makes keys, encrypts and decrypts   ── HTTPS ──> checks who you are and what you may do
  messages, files, descriptions       <─────────── stores unreadable data, hands it back
  never sends a password                           encrypts it again with its own key
```

---

## 2. The API

Every request goes to `auth.php?action=NAME` or `api.php?action=NAME`.

* Reading is a `GET`. Changing something is a `POST`.
* Every `POST` carries the anti-forgery token in the header `X-CSRF-Token`. The token comes from
  `auth.php?action=me` and changes at every sign in.
* Answers are JSON: `{ "ok": true, ... }` or `{ "ok": false, "error": "..." }`.
* It follows REST rules (GET reads, POST changes, JSON in and out, no server-side page state), but the
  address names an action (`?action=...`) instead of a resource path.

### Accounts (`auth.php`)

| Action | Method | Who | Sends | Gets back |
|---|---|---|---|---|
| `me` | GET | anyone | | `username` (or null), `csrf` |
| `register` | POST | anyone | `username`, `email`, `password` (login secret), `public_key`, `wrapped_private_key`, `recovery_proof`, `recovery_private_key` | |
| `login` | POST | anyone | `username`, `password` (login secret) | `username`, `wrapped_private_key`, `csrf` |
| `logout` | POST | anyone | | |
| `change_password` | POST | signed in | `current`, `new`, `wrapped_private_key` | |
| `new_recovery` | POST | signed in | `current`, `recovery_proof`, `recovery_private_key` | |
| `recovery_start` | POST | anyone | `username`, `recovery_proof` | `recovery_private_key` |
| `recovery_finish` | POST | anyone | `username`, `recovery_proof`, `new`, `wrapped_private_key` | |

"Login secret" and "proof" are values made in the browser from the password or recovery code. The real
password and code are never sent.

### Workspace (`api.php`), reading

| Action | Who | Query | Gets back |
|---|---|---|---|
| `sync` | signed in | `community`, `channel`, `after`, `files` (0 or 1) | `users`, `communities`, `messages`, `files` (everything the page needs, in one request) |
| `users` | signed in | | `users` (name + public key) |
| `communities` | signed in | | `communities` (only what you may see) |
| `messages` | channel reader | `community`, `channel`, `after` | `messages` |
| `files` | channel reader | `community`, `channel` | `files` |
| `download_file` | channel reader | `community`, `channel`, `file` | the encrypted file (browser decrypts it) |
| `overview` | member | `community` | `stats`, `recent_files` |
| `activity` | admin | `community` | `events` |
| `list_invites` | admin, sub-admin | `community` | `invites` |
| `invite_info` | signed in | `invite` | community name, who invited, the locked keys |

### Workspace (`api.php`), changing

| Action | Who | Sends |
|---|---|---|
| `create_community` | signed in | `name`, `members`, `roles`, `keys` |
| `add_members` | admin, sub-admin (sub-admins add members only) | `community`, `members`, `roles`, `keys` |
| `set_role` | admin | `community`, `user`, `role`, `keys` |
| `remove_member` | admin | `community`, `user`, `keys` |
| `create_team` | admin, sub-admin | `community`, `channel` (new id), `name`, `members`, `desc_iv`, `desc_ct`, `desc_kv`, `keys` |
| `update_team` | admin, sub-admin (teams they are in) | same, with the team's `channel` id |
| `send_message` | channel reader | `community`, `channel`, `kv`, `iv`, `ct` |
| `upload_file` | channel reader | multipart: `community`, `channel`, `kv`, `iv`, `name_iv`, `name_ct`, `blob` |
| `delete_file` | uploader, admin, sub-admin | `community`, `channel`, `file` |
| `create_invite` | admin, sub-admin | `community`, `iv`, `ct` |
| `revoke_invite` | admin, sub-admin | `community`, `invite` |
| `accept_invite` | signed in | `invite`, `keys` |

`keys` is always JSON: the locked channel keys the server must store, as
`{ channelId: { username: { v1: "...", v2: "..." } } }`. The server refuses any change after which a
reader would be missing a key.

---

## 3. How data is stored

### On the server: the data folder

```
data/                     (set by DATA_DIR in config.php)
├── server.key            The server's own key (32 random bytes). Keep it OUTSIDE the web folder and back it up.
├── users.dat             All accounts
├── communities.dat       Communities, teams, messages, file records, invites, activity log
├── limits.dat            Failed login counters (stored as hashes)
└── files/
    └── <id>.bin          One uploaded file, encrypted on the server in 1 MB pieces
```

Every `.dat` file and every file piece is encrypted with the server key (AES-256-GCM). A copy of the data
folder without `server.key` cannot be read.

What is inside (before the server encrypts it):

```
users.dat       [ { id, username, email, password: hash of the login secret, public_key,
                    wrapped_private_key: private key locked with the password,
                    recovery_hash, recovery_wrapped_private_key: private key locked with the recovery code } ]

communities.dat [ { id, name, created_at,
                    members:  [ { user, role } ],                  role: admin | subadmin | member
                    channels: [ { id, name, type: general | team,
                                  members: [ picked people ],
                                  key_version,
                                  keys:  { user: { v1: lockedKey, v2: lockedKey } },
                                  desc_iv, desc_ct, desc_kv,       the encrypted description
                                  messages: [ { id, user, at, kv, iv, ct } ],
                                  files:    [ { id, user, at, kv, iv, name_iv, name_ct, size } ] } ],
                    invites:  [ { id, by, at, expires, iv, ct } ],
                    activity: [ { at, kind, actor, subject, channel, detail } ] } ]
```

### In the browser

| Where | What |
|---|---|
| `sessionStorage` `tv_private` | Your unlocked private key. It disappears when the tab closes, so you sign in again. |
| `sessionStorage` `tv_invite` | An invite link you opened, until you accept it |
| `localStorage` | Look and feel only: `tv_theme`, `tv_color`, `tv_compact` |

### Who can read what

| Data | Server can read it? | Protected by |
|---|---|---|
| Passwords | No, never sent | Only a hash of a derived "login secret" is stored |
| Private keys | No | Locked with your password and your recovery code |
| Messages, team descriptions, file names, files | No | Channel key (browser), plus the server key on top |
| Usernames, emails, roles, who is in which team, community and team names | Yes | Server key (so a stolen copy is unreadable) |
| Times, file sizes, the activity log | Yes | Server key. The log has names and times, never content |

### Key rules

* Each channel (General or a team) has one key per **version**. Every reader has a locked copy of every
  version, so they can read the whole history.
* When someone loses access (removed, or no longer picked for a team, or no longer an admin), the channel
  gets a **new version** that they never receive.
* A person who gains access gets the existing versions, so they can read the history.
* A person can be in as many teams as they like.

---

## 4. Putting it on the internet

1. **Hosting.** You need PHP 7.4 or newer (8.x is best) with the `openssl` and `mbstring` extensions, free
   HTTPS (Let's Encrypt or AutoSSL), and the ability to raise upload limits. For 100 MB files, check the host
   allows it: many free hosts cap uploads at 10 to 50 MB.
2. **Data folder.** Make a folder **outside** the public web folder, for example `/home/you/teamvault-data`.
   PHP must be able to write to it.
3. **Edit `config.php`.** Set `DATA_DIR` to that folder. Put the key somewhere separate, for example
   `/home/you/teamvault-keys/server.key`, in `SERVER_KEY_FILE`.
4. **Upload** all the project files into the public web folder (upload `teamvault.zip` and extract it).
5. **Rename `htaccess.txt` to `.htaccess`** (Apache hosts). It turns on https, sets security headers and asks PHP
   for room for 100 MB files.
6. **PHP limits.** If your host has a PHP settings page, set `upload_max_filesize` 110M, `post_max_size` 120M,
   `max_execution_time` 300, `memory_limit` 256M.
7. **Turn on HTTPS** for your domain. The browser encryption does not work on plain `http://` pages.
8. **Open `https://your-site/check.php`.** Fix everything marked red, then **delete `check.php`**.
9. **Create the first account** at `login.html`, save its recovery code, and create a community.
10. **Test with a second device.** Register or use an invite link on a phone, send a message, and upload a
    real `.pdf`. Try the biggest file you expect to use.

Before a presentation: do a full dry run on the real network, keep the recovery codes, and keep a copy of
the data folder **and** `server.key` (together they are the backup, and neither is useful alone).

Running on your own computer with XAMPP works the same way. Put the folder in `htdocs` and open
`http://localhost/Teamvault/login.html`.

---

## 5. Limits to know

* Forgotten password **and** lost recovery code means the data cannot be recovered. That is what
  end-to-end encryption means.
* Someone removed from a team keeps whatever they already read and any keys they already loaded.
  The new key protects everything written afterwards.
* The server can see who is in which team and when things happen, but not what is inside.
* File types (`.txt`, `.pdf`, `.docx`) are checked in the browser, because the server never sees file contents.
* Everything is kept in a few encrypted files. That is fine for a team or a class. For hundreds of users,
  move the stores to a database.
