<?php
// TeamVault - accounts backend (register, sign in, password, recovery).
// This file only lists the actions. The work is done in lib/accounts.php.
//
// Every request is   auth.php?action=NAME   with GET for reading and POST for changing.

define('TEAMVAULT', true);
require __DIR__ . '/config.php';
foreach (['core', 'store', 'limits', 'accounts'] as $part) {
    require __DIR__ . '/lib/' . $part . '.php';
}

dispatch([
    'me'              => ['act_me',              'GET',  true],    // who is signed in + the anti-forgery token
    'register'        => ['act_register',        'POST', true],
    'login'           => ['act_login',           'POST', true],
    'logout'          => ['act_logout',          'POST', true],
    'change_password' => ['act_change_password', 'POST', false],
    'new_recovery'    => ['act_new_recovery',    'POST', false],
    'recovery_start'  => ['act_recovery_start',  'POST', true],
    'recovery_finish' => ['act_recovery_finish', 'POST', true],
]);
