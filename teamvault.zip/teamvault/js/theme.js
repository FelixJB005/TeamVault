// Light, dark or "same as my device". Loaded in the <head> so the page never flashes the wrong colors.
// The choice is saved in this browser.

const TVTheme = (() => {
  const query = window.matchMedia('(prefers-color-scheme: dark)');
  const get = () => localStorage.getItem('tv_theme') || 'system';

  function apply() {
    const dark = get() === 'dark' || (get() === 'system' && query.matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  }

  function set(choice) {
    localStorage.setItem('tv_theme', choice);
    apply();
  }

  // The button in the top bar: switches between light and dark
  function toggle() {
    set(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
  }

  apply();
  query.addEventListener('change', apply);
  return { get, set, toggle };
})();
