// TeamVault key rules (runs in the browser, no screens in here).
//
// Every channel has a key VERSION number. Rules:
//  1. Every reader of a channel has a locked copy of every key version, so they can read the whole history.
//  2. When someone loses access to a channel, the channel gets a NEW key version, locked only for the people
//     who can still read it. Messages and files from then on use the new key.
//  3. Someone who gains access gets locked copies of all the existing versions.
// The server checks these rules too. This file only works out which locked keys to send with a request.
//
// The "payload" it returns looks like: { username: { v1: lockedKey, v2: lockedKey } }

const TVKeys = (() => {
  const versionName = (number) => 'v' + number;
  const unique = (list) => [...new Set(list)];

  // Who can read a channel. members: [{ user, role }], explicit: the people picked for a team.
  // General: every member. Team: the picked members plus every admin.
  function readersOf(channel, members, explicit) {
    const names = members.map((m) => m.user);
    if (channel.type === 'general') return names;
    const admins = members.filter((m) => m.role === 'admin').map((m) => m.user);
    return unique([...explicit.filter((user) => names.includes(user)), ...admins]);
  }

  // tools: { keyOf(channel, version) -> CryptoKey or null, publicKeys: { username: publicKeyText } }
  async function lock(key, user, tools) {
    if (!tools.publicKeys[user]) throw new Error(user + ' has no encryption key yet.');
    return TVCrypto.wrapKey(key, tools.publicKeys[user]);
  }

  // The keys to send when the readers of an existing channel change to "after".
  // Returns { payload, version, newKey }: version is the key version after the change, newKey is the new
  // key if there is a new version (null otherwise).
  async function forChange(channel, after, tools) {
    const before = channel.members;
    const removed = before.filter((user) => !after.includes(user));
    const added = after.filter((user) => !before.includes(user));
    const payload = {};
    let newKey = null;

    // Rule 2: somebody lost access, so make a new key version for everyone who is left
    if (removed.length > 0) {
      const name = versionName(channel.key_version + 1);
      newKey = await TVCrypto.newChannelKey();
      for (const user of after) payload[user] = { [name]: await lock(newKey, user, tools) };
    }

    // Rule 3: somebody gained access, so give them every version that exists now
    for (const user of added) {
      payload[user] = payload[user] || {};
      for (let version = 1; version <= channel.key_version; version++) {
        const key = await tools.keyOf(channel, version);
        if (!key) throw new Error('You do not have the key for ' + channel.name + '.');
        payload[user][versionName(version)] = await lock(key, user, tools);
      }
    }
    return { payload, version: channel.key_version + (newKey ? 1 : 0), newKey };
  }

  // A brand new channel: a first key, locked for every reader
  async function forNewChannel(readers, tools) {
    const key = await TVCrypto.newChannelKey();
    const payload = {};
    for (const user of readers) payload[user] = { v1: await lock(key, user, tools) };
    return { key, payload };
  }

  // The keys for every channel of a community after a change to its members.
  // newMembers: [{ user, role }] after the change. teamPeople: { teamId: [users] } to replace the picked people of some teams.
  // Returns { channelId: payload } with only the channels that need something.
  async function forCommunity(community, newMembers, teamPeople, tools) {
    const result = {};
    for (const channel of community.channels) {
      const explicit = teamPeople[channel.id] || channel.explicit || [];
      const after = readersOf(channel, newMembers, explicit);
      const { payload } = await forChange(channel, after, tools);
      if (Object.keys(payload).length > 0) result[channel.id] = payload;
    }
    return result;
  }

  return { versionName, readersOf, forChange, forNewChannel, forCommunity };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = TVKeys;
