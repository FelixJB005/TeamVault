// The Overview tab (numbers, recent files, teams or recent activity) and the Activity tab.

/* ---------- The activity log ---------- */

const EVENT_ICONS = {
  community_created: '\u2605', member_added: '+', member_joined: '\u21AA', member_removed: '\u2212', role_changed: '\u2691',
  team_created: '\u25C6', team_updated: '\u270E', team_member_added: '+', team_member_removed: '\u2212',
  file_uploaded: '\u2191', file_deleted: '\u2715', invite_created: '\u2709', invite_revoked: '\u2715', invites_cleared: '\u21BA',
};

// The sentence for one event. It only holds names, never message text or file names.
function eventText(e) {
  const who = e.actor === me ? 'You' : e.actor;
  const target = e.subject === me ? 'you' : e.subject;
  switch (e.kind) {
    case 'community_created': return who + ' created the community';
    case 'member_added': return who + ' added ' + target + ' as ' + (ROLE_LABELS[e.detail] || 'member').toLowerCase();
    case 'member_joined': return who + ' joined with an invite from ' + e.detail;
    case 'member_removed': return who + ' removed ' + target + ' from the community';
    case 'role_changed': return who + ' made ' + target + ' ' + (ROLE_LABELS[e.detail] || e.detail).toLowerCase();
    case 'team_created': return who + ' created the team ' + e.channel;
    case 'team_updated': return who + ' edited the team ' + e.channel;
    case 'team_member_added': return who + ' added ' + target + ' to ' + e.channel;
    case 'team_member_removed': return who + ' removed ' + target + ' from ' + e.channel;
    case 'file_uploaded': return who + ' uploaded a file to ' + e.channel + ' (' + formatSize(Number(e.detail)) + ')';
    case 'file_deleted': return who + ' deleted a file from ' + e.channel;
    case 'invite_created': return who + ' made an invite link';
    case 'invite_revoked': return who + ' revoked an invite link';
    case 'invites_cleared': return 'Open invite links were cleared because the community key changed';
    default: return who + ' did something';
  }
}

function makeEvent(e) {
  const text = make('div');
  text.append(make('p', '', eventText(e)), make('time', '', formatTime(e.at)));
  const row = make('div', 'event');
  row.append(make('div', 'event-dot', EVENT_ICONS[e.kind] || '\u2022'), text);
  return row;
}

function dayLabel(seconds) {
  const day = new Date(seconds * 1000).toDateString();
  if (day === new Date().toDateString()) return 'Today';
  if (day === new Date(Date.now() - 86400000).toDateString()) return 'Yesterday';
  return formatDate(seconds);
}

async function drawActivity() {
  const openId = currentCommunityId;
  const data = await TVApi.get('activity', { community: openId });
  if (!data.ok || openId !== currentCommunityId) return;
  const list = $('activityList');
  list.replaceChildren();
  if (data.events.length === 0) list.append(make('p', 'hint', 'Nothing has happened yet.'));
  let lastDay = '';
  for (const event of data.events) {
    const label = dayLabel(event.at);
    if (label !== lastDay) {
      list.append(make('div', 'day-label', label));
      lastDay = label;
    }
    list.append(makeEvent(event));
  }
}

/* ---------- The overview ---------- */

async function drawOverview() {
  const community = currentCommunity();
  if (!community) return;
  const openId = community.id;

  $('overviewDate').textContent = new Date().toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase();
  $('overviewIntro').textContent = community.name + ' \u00B7 you are ' + (community.role === 'admin' ? 'an admin' : community.role === 'subadmin' ? 'a sub-admin' : 'a member');
  $('sideTitle').textContent = isAdmin() ? 'Recent activity' : 'Your teams';
  $('sideSub').textContent = isAdmin() ? 'What happened lately' : 'The teams you are in';

  const data = await TVApi.get('overview', { community: openId });
  if (!data.ok || openId !== currentCommunityId) return;
  $('metricFiles').textContent = data.stats.files;
  $('metricMembers').textContent = data.stats.members;
  $('metricTeams').textContent = data.stats.teams;
  $('metricStorage').textContent = formatSize(data.stats.bytes);

  // Recent files: the names are encrypted, so each one is decrypted with the key of its channel
  const recent = $('recentFiles');
  const rows = [];
  for (const item of data.recent_files) {
    const channel = community.channels.find((c) => c.id === item.channel);
    const [file] = channel ? await decryptFiles(channel, [item]) : [{ ...item, name: '(unreadable file name)' }];
    rows.push(makeFileRow({ ...file, where: item.channel_name }, null));
  }
  if (rows.length === 0) rows.push(make('p', 'hint', 'No files yet. Upload one from the Files tab.'));
  recent.replaceChildren(...rows);

  // The side panel: recent activity for admins, your teams for everybody else
  const side = $('sideBody');
  if (isAdmin()) {
    const log = await TVApi.get('activity', { community: openId });
    const events = log.ok ? log.events.slice(0, 5).map(makeEvent) : [];
    side.replaceChildren(...(events.length ? events : [make('p', 'hint', 'Nothing has happened yet.')]));
  } else {
    const teams = community.channels.filter((c) => c.type === 'team');
    const cards = teams.map((team) => {
      const button = make('button', 'item', '\u25C6 ' + team.name);
      button.type = 'button';
      button.addEventListener('click', () => openChannel(openId, team.id, 'chat'));
      return button;
    });
    side.replaceChildren(...(cards.length ? cards : [make('p', 'hint', 'You are not in a team yet.')]));
  }
}

$('overviewUpload').addEventListener('click', () => showTab('files'));
$('goFiles').addEventListener('click', () => showTab('files'));
$('goSide').addEventListener('click', () => showTab(isAdmin() ? 'activity' : 'members'));
