// TeamVault encryption. Runs only in the browser and uses the built-in Web Crypto API.
//
// The big picture:
//  - Every user has an RSA key pair. The public key is stored on the server. The private key is stored on
//    the server too, but locked with a key made from the user's password (and a second copy locked with
//    the user's recovery code).
//  - Every channel (General or a team) has an AES key for each "key version". Messages, descriptions and
//    files are encrypted with it. The server keeps one locked copy of each key version for every reader.
//  - The server never sees a password, a private key, a channel key, a message or a file in readable form.

const TVCrypto = (() => {
  const subtle = globalThis.crypto.subtle;
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const PASSWORD_ITERATIONS = 250000;              // makes password guessing slow
  const RECOVERY_ITERATIONS = 100000;              // recovery codes are random, so fewer rounds are enough
  const RSA = { name: 'RSA-OAEP', hash: 'SHA-256' };
  const CHUNK_SIZE = 4 * 1024 * 1024;              // files are encrypted in 4 MB pieces

  /* ---------- Base64 helpers ---------- */

  function toB64(buffer) {
    const bytes = new Uint8Array(buffer);
    let text = '';
    for (let i = 0; i < bytes.length; i += 0x8000) {
      text += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    }
    return btoa(text);
  }

  function fromB64(text) {
    const raw = atob(text);
    const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    return bytes;
  }

  // The URL safe version, used for invite secrets that travel inside a link
  const toB64Url = (buffer) => toB64(buffer).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const fromB64Url = (text) => fromB64(text.replace(/-/g, '+').replace(/_/g, '/'));
  const toHex = (buffer) => [...new Uint8Array(buffer)].map((b) => b.toString(16).padStart(2, '0')).join('');

  /* ---------- Secrets: passwords and recovery codes ---------- */

  function secretKey(secret) {
    return subtle.importKey('raw', encoder.encode(secret), 'PBKDF2', false, ['deriveBits', 'deriveKey']);
  }

  // A value made from a secret and a label. The server only ever receives this, never the secret.
  async function deriveProof(label, secret, iterations) {
    const bits = await subtle.deriveBits(
      { name: 'PBKDF2', salt: encoder.encode(label), iterations, hash: 'SHA-256' },
      await secretKey(secret),
      256
    );
    return toHex(bits);
  }

  // What the server gets instead of the password
  const loginSecret = (username, password) =>
    deriveProof('teamvault-login:' + username.trim().toLowerCase(), password, PASSWORD_ITERATIONS);

  // Lock a text with a secret (a password or a recovery code). Returns a JSON text that is safe to store on the server.
  async function sealWithSecret(plainText, secret, iterations) {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await subtle.deriveKey(
      { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
      await secretKey(secret),
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt']
    );
    const data = await subtle.encrypt({ name: 'AES-GCM', iv }, key, encoder.encode(plainText));
    return JSON.stringify({ salt: toB64(salt), iv: toB64(iv), data: toB64(data), iter: iterations });
  }

  // Unlock a text made by sealWithSecret. Throws if the secret is wrong.
  async function openWithSecret(sealedText, secret) {
    const sealed = JSON.parse(sealedText);
    const key = await subtle.deriveKey(
      { name: 'PBKDF2', salt: fromB64(sealed.salt), iterations: sealed.iter, hash: 'SHA-256' },
      await secretKey(secret),
      { name: 'AES-GCM', length: 256 },
      false,
      ['decrypt']
    );
    const plain = await subtle.decrypt({ name: 'AES-GCM', iv: fromB64(sealed.iv) }, key, fromB64(sealed.data));
    return decoder.decode(plain);
  }

  /* ---------- Account keys ---------- */

  // At registration: make a key pair. The private key is returned as text (JWK) so it can be locked in several ways.
  async function createAccountKeys() {
    const pair = await subtle.generateKey(
      { ...RSA, modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]) },
      true,
      ['encrypt', 'decrypt']
    );
    return {
      publicKey: JSON.stringify(await subtle.exportKey('jwk', pair.publicKey)),
      privateKey: JSON.stringify(await subtle.exportKey('jwk', pair.privateKey)),
    };
  }

  const lockPrivateKey = (privateKeyText, password) => sealWithSecret(privateKeyText, password, PASSWORD_ITERATIONS);
  const unlockPrivateKey = (sealedText, password) => openWithSecret(sealedText, password);

  const importPrivateKey = (jwkText) => subtle.importKey('jwk', JSON.parse(jwkText), RSA, false, ['decrypt']);
  const importPublicKey = (jwkText) => subtle.importKey('jwk', JSON.parse(jwkText), RSA, false, ['encrypt']);

  /* ---------- Recovery code ---------- */

  const BASE32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

  // 32 random characters (160 bits), shown as 8 groups of 4: ABCD-EFGH-...
  function newRecoveryCode() {
    const bytes = crypto.getRandomValues(new Uint8Array(32));
    const letters = [...bytes].map((b) => BASE32[b % 32]).join('');
    return letters.match(/.{4}/g).join('-');
  }

  // People type codes in lower case, with spaces or without dashes. Make them all look the same.
  const normalizeRecoveryCode = (text) => text.toUpperCase().replace(/[^A-Z2-7]/g, '');

  const recoveryProof = (username, code) =>
    deriveProof('teamvault-recovery:' + username.trim().toLowerCase(), normalizeRecoveryCode(code), RECOVERY_ITERATIONS);

  // Everything the server stores for the recovery code: a proof (so it can check the code) and a locked copy of the private key
  async function makeRecovery(username, privateKeyText, code) {
    return {
      proof: await recoveryProof(username, code),
      sealedPrivateKey: await sealWithSecret(privateKeyText, normalizeRecoveryCode(code), RECOVERY_ITERATIONS),
    };
  }

  const unlockWithRecovery = (sealedText, code) => openWithSecret(sealedText, normalizeRecoveryCode(code));

  /* ---------- Channel keys ---------- */

  const newChannelKey = () => subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);

  // Lock a channel key for one person, using their public key (JWK text)
  async function wrapKey(channelKey, publicKeyText) {
    const raw = await subtle.exportKey('raw', channelKey);
    const locked = await subtle.encrypt({ name: 'RSA-OAEP' }, await importPublicKey(publicKeyText), raw);
    return toB64(locked);
  }

  // Unlock a channel key with your own private key
  async function unwrapKey(wrappedB64, privateKey) {
    const raw = await subtle.decrypt({ name: 'RSA-OAEP' }, privateKey, fromB64(wrappedB64));
    return subtle.importKey('raw', raw, { name: 'AES-GCM' }, true, ['encrypt', 'decrypt']);
  }

  /* ---------- Invite links ---------- */
  // The secret lives only in the part of the link after the #, which browsers never send to the server.
  // The channel keys are locked with it, so the server holds them but cannot open them.

  const newInviteSecret = () => toB64Url(crypto.getRandomValues(new Uint8Array(32)));

  const inviteKey = (secret, usage) => subtle.importKey('raw', fromB64Url(secret), { name: 'AES-GCM' }, false, [usage]);

  // keys: { v1: CryptoKey, v2: CryptoKey, ... }
  async function sealKeysForInvite(secret, keys) {
    const raw = {};
    for (const name in keys) raw[name] = toB64(await subtle.exportKey('raw', keys[name]));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const data = await subtle.encrypt({ name: 'AES-GCM', iv }, await inviteKey(secret, 'encrypt'), encoder.encode(JSON.stringify(raw)));
    return { iv: toB64(iv), ct: toB64(data) };
  }

  async function openInviteKeys(secret, ivB64, ctB64) {
    const plain = await subtle.decrypt({ name: 'AES-GCM', iv: fromB64(ivB64) }, await inviteKey(secret, 'decrypt'), fromB64(ctB64));
    const raw = JSON.parse(decoder.decode(plain));
    const keys = {};
    for (const name in raw) keys[name] = await subtle.importKey('raw', fromB64(raw[name]), { name: 'AES-GCM' }, true, ['encrypt', 'decrypt']);
    return keys;
  }

  /* ---------- Messages and descriptions ---------- */

  async function encryptText(key, text) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const data = await subtle.encrypt({ name: 'AES-GCM', iv }, key, encoder.encode(text));
    return { iv: toB64(iv), ct: toB64(data) };
  }

  async function decryptText(key, ivB64, ctB64) {
    const plain = await subtle.decrypt({ name: 'AES-GCM', iv: fromB64(ivB64) }, key, fromB64(ctB64));
    return decoder.decode(plain);
  }

  /* ---------- Files ---------- */
  // Files are encrypted in chunks, so even a 100 MB file does not need huge buffers.
  // Every chunk has its own IV (a random part plus the chunk number) and the last chunk is marked,
  // so chunks cannot be reordered, removed or cut off without the decryption failing.

  function chunkIv(base, index) {
    const iv = new Uint8Array(12);
    iv.set(base, 0);
    new DataView(iv.buffer).setUint32(8, index);
    return iv;
  }

  // file: a File or Blob. Returns the IV text and a Blob with the encrypted data.
  async function encryptFile(key, file, chunkSize = CHUNK_SIZE) {
    const base = crypto.getRandomValues(new Uint8Array(8));
    const total = Math.max(1, Math.ceil(file.size / chunkSize));
    const parts = [];
    for (let i = 0; i < total; i++) {
      const plain = await file.slice(i * chunkSize, (i + 1) * chunkSize).arrayBuffer();
      const last = new Uint8Array([i === total - 1 ? 1 : 0]);
      parts.push(await subtle.encrypt({ name: 'AES-GCM', iv: chunkIv(base, i), additionalData: last }, key, plain));
    }
    return { iv: toB64(base), blob: new Blob(parts) };
  }

  // buffer: the encrypted data as an ArrayBuffer. Returns a Blob with the original file. Throws if anything was changed.
  async function decryptFile(key, ivB64, buffer, chunkSize = CHUNK_SIZE) {
    const base = fromB64(ivB64);
    const step = chunkSize + 16;                       // each chunk has a 16 byte check value
    const total = Math.max(1, Math.ceil(buffer.byteLength / step));
    const parts = [];
    for (let i = 0; i < total; i++) {
      const piece = buffer.slice(i * step, (i + 1) * step);
      const last = new Uint8Array([i === total - 1 ? 1 : 0]);
      parts.push(await subtle.decrypt({ name: 'AES-GCM', iv: chunkIv(base, i), additionalData: last }, key, piece));
    }
    return new Blob(parts);
  }

  return {
    loginSecret,
    createAccountKeys, lockPrivateKey, unlockPrivateKey, importPrivateKey,
    newRecoveryCode, normalizeRecoveryCode, recoveryProof, makeRecovery, unlockWithRecovery,
    newChannelKey, wrapKey, unwrapKey,
    newInviteSecret, sealKeysForInvite, openInviteKeys,
    encryptText, decryptText, encryptFile, decryptFile,
  };
})();

// Lets the test scripts load this file in Node
if (typeof module !== 'undefined' && module.exports) module.exports = TVCrypto;
