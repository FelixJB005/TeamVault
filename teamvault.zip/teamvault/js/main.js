// The workspace page: starting up, and asking the server for news every few seconds.

/* ---------- Keeping up with the server ---------- */

let syncing = false;
let syncAgain = false;
let syncPromise = null;

// One request brings everything new: the people, the communities, and for the open channel
// the new messages and (on the Files tab) the file list.
async function syncOnce() {
  const communityId = currentCommunityId;
  const channelId = currentChannelId;
  const tab = currentTab;
  const data = await TVApi.get('sync', { community: communityId || '', channel: channelId || '', after: lastMessageId, files: tab === 'files' ? '1' : '0' });
  if (!data.ok) return;

  people = data.users.map((user) => user.username);
  for (const user of data.users) publicKeys[user.username] = user.public_key;

  // Only redraw when something changed
  if (JSON.stringify(data.communities) !== JSON.stringify(communities)) {
    communities = data.communities;
    refreshView();
  }

  // Ignore the news for a channel if something else was opened meanwhile
  if (communityId === currentCommunityId && channelId === currentChannelId) {
    if (data.messages) await addMessages(data.messages);
    if (data.files && tab === currentTab) await applyFiles(data.files);
  }
}

// Ask the server now. If a request is already running, one more follows it.
function sync() {
  if (syncing) {
    syncAgain = true;
    return syncPromise;
  }
  syncing = true;
  syncPromise = (async () => {
    try {
      do {
        syncAgain = false;
        await syncOnce();
      } while (syncAgain);
    } finally {
      syncing = false;
    }
  })();
  return syncPromise;
}

/* ---------- Top bar buttons ---------- */

function drawThemeButton() {
  const dark = document.documentElement.dataset.theme === 'dark';
  $('themeButton').textContent = dark ? '\u2600' : '\u263E';
  $('themeButton').setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
}

$('themeButton').addEventListener('click', () => {
  TVTheme.toggle();
  drawThemeButton();
});

async function signOut() {
  sessionStorage.removeItem('tv_private');
  await TVApi.auth('logout');
  window.location.href = 'login.html';
}
$('logoutButton').addEventListener('click', signOut);

/* ---------- Start ---------- */

async function start() {
  // 1. Only signed in users can see this page
  const who = await TVApi.start();
  if (!who.username) {
    window.location.href = 'login.html';
    return;
  }
  me = who.username;

  // 2. Your private key was unlocked with your password when you signed in.
  //    If it is missing (for example a new tab), sign in again to unlock it.
  const savedKey = sessionStorage.getItem('tv_private');
  if (!savedKey || !window.crypto || !window.crypto.subtle) {
    await signOut();
    return;
  }
  privateKey = await TVCrypto.importPrivateKey(savedKey);

  // 3. Profile picture, menu and look
  const profile = $('profileButton');
  profile.textContent = initials(me);
  profile.dataset.name = me;
  $('menuName').textContent = me;
  document.body.classList.toggle('compact', settings.compact);
  drawThemeButton();
  refreshAvatars();

  // 4. Load everything, then offer an invite if the person came from an invite link
  renderCommunities();
  await sync();
  await offerInvite();

  // 5. Check for news every 3 seconds (every 15 seconds while the tab is hidden)
  let ticks = 0;
  setInterval(() => {
    ticks++;
    if (document.hidden && ticks % 5 !== 0) return;
    sync();
    if (ticks % 4 === 0 && currentCommunityId) {            // the numbers and the activity log change more slowly
      if (currentTab === 'overview') drawOverview();
      if (currentTab === 'activity') drawActivity();
    }
  }, 3000);
}

start();
