// Files: listing, uploading (encrypted here, in pieces), downloading (decrypted here) and deleting.

const fileExtension = (name) => (name.lastIndexOf('.') > 0 ? name.slice(name.lastIndexOf('.') + 1).toLowerCase() : '');

// Only .txt, .pdf and .docx files up to 100 MB. The server cannot see file names or contents
// (they are encrypted), so these checks are made here. Returns a problem text, or '' if the file is fine.
async function checkFile(file) {
  const ext = fileExtension(file.name);
  if (!FILE_TYPES[ext]) return 'Only .txt, .pdf and .docx files are allowed.';
  if (file.size === 0) return 'The file is empty.';
  if (file.size > MAX_FILE_BYTES) return 'Files can be at most 100 MB.';

  // Make sure the content really matches the extension
  const head = new Uint8Array(await file.slice(0, 1024).arrayBuffer());
  const asText = new TextDecoder('latin1').decode(head);
  if (ext === 'pdf' && !asText.includes('%PDF-')) return 'This is not a real PDF file.';
  if (ext === 'docx' && !(head[0] === 0x50 && head[1] === 0x4b && head[2] === 3 && head[3] === 4)) return 'This is not a real Word (.docx) file.';
  const hasBom = (head[0] === 0xff && head[1] === 0xfe) || (head[0] === 0xfe && head[1] === 0xff);
  if (ext === 'txt' && !hasBom && head.includes(0)) return 'This is not a plain text file.';
  return '';
}

// One row of a file list. actions: a node with buttons, or null.
function makeFileRow(file, actions) {
  const info = make('div', 'file-info');
  info.append(
    make('div', 'file-name', file.name),
    make('div', 'file-meta', formatSize(file.size) + ' \u00B7 ' + (file.user === me ? 'you' : file.user) + ' \u00B7 ' + formatDate(file.at) + (file.where ? ' \u00B7 ' + file.where : ''))
  );
  const ext = fileExtension(file.name);
  const row = make('div', 'file-row');
  row.append(make('div', 'file-icon', ext ? ext.slice(0, 4).toUpperCase() : 'FILE'), info);
  if (actions) row.append(actions);
  return row;
}

function renderFiles(files) {
  const list = $('fileList');
  list.replaceChildren();
  if (files.length === 0) {
    list.append(make('p', 'hint', 'No files yet. Upload one and it is encrypted in your browser first.'));
  }
  for (const file of files) {
    const actions = make('div', 'file-actions');
    const download = make('button', 'secondary', 'Download');
    download.type = 'button';
    download.addEventListener('click', () => downloadFile(file, download));
    actions.append(download);
    if (file.user === me || canManage()) {
      const remove = make('button', 'danger', 'Delete');
      remove.type = 'button';
      remove.addEventListener('click', () => deleteFile(file));
      actions.append(remove);
    }
    list.append(makeFileRow(file, actions));
  }
}

// Decrypt the names of the files the server listed, and show them
async function decryptFiles(channel, list) {
  const files = [];
  for (const file of list) {
    let info = { name: '(unreadable file name)', type: '', size: file.size };
    try {
      const key = await keyOf(channel, file.kv);
      if (key) info = { ...info, ...JSON.parse(await TVCrypto.decryptText(key, file.name_iv, file.name_ct)) };
    } catch (error) {}
    files.push({ ...file, name: info.name, type: info.type, size: info.size });
  }
  return files;
}

// Called with the file list from the server. Only redraws when something changed.
async function applyFiles(list) {
  const signature = JSON.stringify(list.map((f) => f.id));
  if (signature === filesSignature) return;
  filesSignature = signature;
  const openId = currentChannelId;
  const files = await decryptFiles(currentChannel(), list);
  if (openId === currentChannelId) renderFiles(files);
}

async function uploadFile(file) {
  const channel = currentChannel();
  const problem = await checkFile(file);
  if (problem) {
    toast(file.name + ': ' + problem, true);
    return;
  }
  const status = $('uploadStatus');
  try {
    const key = await keyOf(channel);
    if (!key) throw new Error('You do not have the key for this chat.');

    // Encrypt the file and its name here, then upload only the encrypted data
    status.textContent = 'Encrypting ' + file.name + '...';
    const encryptedFile = await TVCrypto.encryptFile(key, file);
    const meta = { name: file.name, type: FILE_TYPES[fileExtension(file.name)], size: file.size };
    const encryptedName = await TVCrypto.encryptText(key, JSON.stringify(meta));

    const form = new FormData();
    form.append('community', currentCommunityId);
    form.append('channel', channel.id);
    form.append('kv', channel.key_version);
    form.append('iv', encryptedFile.iv);
    form.append('name_iv', encryptedName.iv);
    form.append('name_ct', encryptedName.ct);
    form.append('blob', encryptedFile.blob, 'file.enc');

    const data = await TVApi.upload('upload_file', form, (percent) => { status.textContent = 'Uploading ' + file.name + '... ' + percent + '%'; });
    if (!data.ok) throw new Error(data.error);
  } catch (error) {
    toast('Could not upload ' + file.name + ': ' + error.message, true);
  } finally {
    status.textContent = '';
  }
}

async function uploadMany(files) {
  for (const file of files) await uploadFile(file);
  filesSignature = '';
  sync();
}

$('fileInput').addEventListener('change', (event) => {
  const picked = [...event.target.files];
  event.target.value = '';
  uploadMany(picked);
});

// Drop files anywhere on the Files tab
$('filesPane').addEventListener('dragover', (event) => {
  event.preventDefault();
  $('fileList').classList.add('dragging');
});
$('filesPane').addEventListener('dragleave', () => $('fileList').classList.remove('dragging'));
$('filesPane').addEventListener('drop', (event) => {
  event.preventDefault();
  $('fileList').classList.remove('dragging');
  uploadMany([...event.dataTransfer.files]);
});

async function downloadFile(file, button) {
  const label = button.textContent;
  button.disabled = true;
  button.textContent = 'Decrypting...';
  try {
    const key = await keyOf(currentChannel(), file.kv);
    if (!key) throw new Error('You do not have the key for this file.');

    const response = await TVApi.raw('download_file', { community: currentCommunityId, channel: currentChannelId, file: file.id });
    if ((response.headers.get('content-type') || '').includes('json')) {
      throw new Error((await response.json()).error);
    }

    // Decrypt in the browser, then save the readable file
    const plain = await TVCrypto.decryptFile(key, file.iv, await response.arrayBuffer());
    const url = URL.createObjectURL(plain.slice(0, plain.size, file.type || 'application/octet-stream'));
    const link = make('a');
    link.href = url;
    link.download = file.name;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  } catch (error) {
    toast('Could not download ' + file.name + ': ' + error.message, true);
  } finally {
    button.disabled = false;
    button.textContent = label;
  }
}

async function deleteFile(file) {
  const yes = await askConfirm('Delete this file?', file.name + ' will be removed for everyone in this channel.', 'Delete');
  if (!yes) return;
  const data = await perform('delete_file', { community: currentCommunityId, channel: currentChannelId, file: file.id });
  if (data.ok) {
    filesSignature = '';
    sync();
  }
}
