// The frame of the workspace page: menus, the sidebar, the tabs, and opening a community or channel.

const TAB_PANES = { overview: 'overviewPane', chat: 'chatPane', files: 'filesPane', members: 'membersPane', activity: 'activityPane' };
const TAB_BUTTONS = { overview: 'tabOverview', chat: 'tabChat', files: 'tabFiles', members: 'tabMembers', activity: 'tabActivity' };

/* ---------- Dropdown menus ---------- */

function closeMenus() {
  document.querySelectorAll('.menu').forEach((menu) => { menu.hidden = true; });
  document.querySelectorAll('[aria-expanded]').forEach((button) => button.setAttribute('aria-expanded', 'false'));
}

function setupMenu(buttonId, menuId) {
  $(buttonId).addEventListener('click', (event) => {
    event.stopPropagation();
    const open = $(menuId).hidden;
    closeMenus();
    $(menuId).hidden = !open;
    $(buttonId).setAttribute('aria-expanded', open);
  });
}

document.addEventListener('click', closeMenus);
setupMenu('profileButton', 'profileMenu');
setupMenu('chatMenuButton', 'chatMenu');

/* ---------- The sidebar drawer on phones ---------- */

function setDrawer(open) {
  document.body.classList.toggle('drawer-open', open);
  $('drawerShade').hidden = !open;
}
const closeDrawer = () => setDrawer(false);

$('drawerButton').addEventListener('click', () => setDrawer(!document.body.classList.contains('drawer-open')));
$('drawerShade').addEventListener('click', closeDrawer);

/* ---------- Sidebar lists ---------- */

function renderCommunities() {
  const list = $('communityList');
  list.replaceChildren();
  if (communities.length === 0) list.append(make('li', 'hint', 'No communities yet'));

  for (const community of communities) {
    const icon = make('span', 'group-icon', initials(community.name));
    icon.style.background = hashColor(community.name);

    const button = make('button', 'item' + (community.id === currentCommunityId ? ' active' : ''));
    button.type = 'button';
    button.append(icon, make('span', 'item-name', community.name));
    button.addEventListener('click', () => openChannel(community.id, 'general'));

    const row = make('li');
    row.append(button);
    list.append(row);
  }
}

function channelRow(channel) {
  const button = make('button', 'item' + (channel.id === currentChannelId ? ' active' : ''));
  button.type = 'button';
  button.append(make('span', 'hash', channel.type === 'general' ? '#' : '\u25C6'), make('span', 'item-name', channel.name));
  button.addEventListener('click', () => openChannel(currentCommunityId, channel.id, 'chat'));
  const row = make('li');
  row.append(button);
  return row;
}

function renderChannels() {
  const community = currentCommunity();
  $('channelList').replaceChildren();
  $('teamList').replaceChildren();
  for (const channel of community.channels) {
    (channel.type === 'general' ? $('channelList') : $('teamList')).append(channelRow(channel));
  }
  if ($('teamList').children.length === 0) {
    $('teamList').append(make('li', 'hint', canManage() ? 'No teams yet. Use + to create one.' : 'You are not in a team yet.'));
  }
  $('communityInfo').replaceChildren(make('strong', '', community.name), makeBadge(community.role));
}

/* ---------- Showing a community and its channel ---------- */

function showEmpty() {
  $('emptyState').hidden = false;
  $('workspace').hidden = true;
  $('navTabs').hidden = true;
  $('communityPanel').hidden = true;
  document.body.classList.remove('has-tabs');
  renderCommunities();
}

// The description of a team is encrypted, so it is decrypted here and shown under the title
async function showDescription() {
  const openId = currentChannelId;
  const text = await descriptionOf(currentChannel());
  if (openId !== currentChannelId) return;
  $('chatDescription').textContent = text;
  $('chatDescription').hidden = !text;
}

// Redraw the sidebar, the page header and the buttons for what is open
function showCommunity() {
  const community = currentCommunity();
  const channel = currentChannel();
  const manage = canManage();

  $('emptyState').hidden = true;
  $('workspace').hidden = false;
  $('navTabs').hidden = false;
  $('communityPanel').hidden = false;
  document.body.classList.add('has-tabs');
  renderCommunities();
  renderChannels();

  const count = channel.members.length;
  $('chatTitle').textContent = (channel.type === 'general' ? '# ' : '\u25C6 ') + channel.name;
  $('chatSub').textContent = community.name + ' \u00B7 ' + count + (count === 1 ? ' person' : ' people');
  $('chatSub').title = channel.members.join(', ');
  showDescription();

  // Only admins and sub-admins see the management buttons. Only admins see the activity log.
  $('chatMenuButton').hidden = !manage;
  $('menuAddPeople').hidden = !manage;
  $('menuNewTeam').hidden = !manage;
  $('menuEditTeam').hidden = !(manage && channel.type === 'team');
  $('sideNewTeam').hidden = !manage;
  $('addPeople').hidden = !manage;
  $('newTeam').hidden = !manage;
  $('inviteSection').hidden = !manage;
  $('tabActivity').hidden = !isAdmin();
  if (currentTab === 'activity' && !isAdmin()) showTab('overview');
  if (currentTab === 'members') drawMembersPane();
}

// After the lists changed: keep what is open, or pick something that still exists
function refreshView() {
  const community = currentCommunity();
  if (!community) {
    if (communities.length > 0) openChannel(communities[0].id, 'general');
    else showEmpty();
  } else if (!currentChannel()) {
    openChannel(community.id, 'general', 'overview');
  } else {
    showCommunity();
  }
}

// Open a channel. tab: which tab to show (when it is left out: the Overview for a new community, otherwise the same tab).
function openChannel(communityId, channelId, tab = null) {
  const communityChanged = communityId !== currentCommunityId;
  const same = !communityChanged && channelId === currentChannelId;
  if (!same) {
    currentCommunityId = communityId;
    currentChannelId = channelId;
    lastMessageId = 0;
    filesSignature = '';
    $('messages').querySelectorAll('.message').forEach((node) => node.remove());
    $('noMessages').hidden = false;
    $('fileList').replaceChildren();
    showCommunity();
  }
  showTab(tab || (communityChanged ? 'overview' : currentTab));
  if (!same) sync();
  if (currentTab === 'chat') $('messageInput').focus();
}

/* ---------- Tabs ---------- */

function showTab(name) {
  if (name === 'activity' && !isAdmin()) name = 'overview';
  currentTab = name;
  for (const tab in TAB_PANES) {
    $(TAB_PANES[tab]).hidden = tab !== name;
    $(TAB_BUTTONS[tab]).classList.toggle('active', tab === name);
  }
  $('channelHead').hidden = name !== 'chat' && name !== 'files';
  closeDrawer();
  if (name === 'files') { filesSignature = ''; sync(); }
  if (name === 'overview') drawOverview();
  if (name === 'members') drawMembersPane();
  if (name === 'activity') drawActivity();
}

for (const tab in TAB_BUTTONS) {
  $(TAB_BUTTONS[tab]).addEventListener('click', () => showTab(tab));
}
