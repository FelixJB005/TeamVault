// The workspace page: shared state, small helpers, and the rules for who may do what.
// (Every script of this page shares these names. The order they load in is in main.html.)

const COLORS = ['#16a34a', '#0d9488', '#2563eb', '#7c3aed', '#db2777', '#ea580c'];
const ROLE_LABELS = { admin: 'Admin', subadmin: 'Sub-admin', member: 'Member' };
const MAX_FILE_BYTES = 100 * 1024 * 1024;
const FILE_TYPES = {
  txt: 'text/plain',
  pdf: 'application/pdf',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
};

/* ---------- What the page knows ---------- */

let me = '';                    // username of the signed in user
let privateKey = null;          // your private key, used to unlock channel keys
const publicKeys = {};          // username -> public key, used to lock keys for other people
const keyCache = new Map();     // locked channel key -> unlocked channel key
let people = [];                // usernames of everyone registered
let communities = [];           // communities this user belongs to (from the server)
let currentCommunityId = null;  // community that is open
let currentChannelId = null;    // channel that is open: 'general' or a team id
let currentTab = 'overview';    // 'overview', 'chat', 'files', 'members' or 'activity'
let lastMessageId = 0;          // newest message shown in the open channel
let filesSignature = '';        // used to redraw the file list only when it changed
let editingTeam = null;         // the team being edited in the team dialog (null when creating)

// Settings that are saved in this browser
const settings = {
  color: localStorage.getItem('tv_color') || COLORS[0],
  compact: localStorage.getItem('tv_compact') === '1',
};

const $ = (id) => document.getElementById(id);

/* ---------- Small helpers ---------- */

// Create an element. Using textContent keeps user text safe.
function make(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

// Initials for the profile picture: "Felix Joy" -> "FJ", "felix" -> "F"
function initials(name) {
  const parts = name.trim().split(/[\s._-]+/).filter(Boolean);
  const first = (word) => Array.from(word)[0];
  const letters = parts.length > 1 ? first(parts[0]) + first(parts[1]) : first(parts[0] || '?');
  return letters.toUpperCase();
}

// The same text always gives the same color
function hashColor(text) {
  let sum = 0;
  for (const ch of text) sum += ch.codePointAt(0);
  return COLORS[sum % COLORS.length];
}

// You get the color from Settings, everyone else gets one based on their name
const colorFor = (name) => (name === me ? settings.color : hashColor(name));

function makeAvatar(name, extraClass = '') {
  const avatar = make('span', 'avatar ' + extraClass, initials(name));
  avatar.dataset.name = name;
  avatar.style.background = colorFor(name);
  return avatar;
}

// Recolor every avatar on the page (after a Settings change)
function refreshAvatars() {
  document.querySelectorAll('.avatar[data-name]').forEach((avatar) => {
    avatar.style.background = colorFor(avatar.dataset.name);
  });
}

function makeBadge(role) {
  const className = role === 'admin' ? 'badge' : role === 'subadmin' ? 'badge sub' : 'badge plain';
  return make('span', className, ROLE_LABELS[role] || 'Member');
}

const formatTime = (seconds) => new Date(seconds * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const formatDate = (seconds) => new Date(seconds * 1000).toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' });

function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + ' KB';
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
}

const randomId = () => [...crypto.getRandomValues(new Uint8Array(6))].map((b) => b.toString(16).padStart(2, '0')).join('');

// A short pop-up message at the bottom of the screen
let toastTimer = null;
function toast(message, bad = false) {
  const box = $('toast');
  box.textContent = message;
  box.classList.toggle('bad', bad);
  box.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => box.classList.remove('show'), bad ? 6000 : 3500);
}

// Send a change to the server. If it fails the reason is shown as a pop-up message.
async function perform(action, fields) {
  const data = await TVApi.post(action, fields);
  if (!data.ok) toast(data.error, true);
  return data;
}

/* ---------- What is open right now, and what you are allowed to do ---------- */

const currentCommunity = () => communities.find((c) => c.id === currentCommunityId);

function currentChannel() {
  const community = currentCommunity();
  return community && community.channels.find((ch) => ch.id === currentChannelId);
}

const myRole = () => (currentCommunity() ? currentCommunity().role : '');

// Admins change roles and remove people. Admins and sub-admins add people, create teams and make invite links.
const isAdmin = () => myRole() === 'admin';
const canManage = () => myRole() === 'admin' || myRole() === 'subadmin';

/* ---------- Encryption keys ---------- */

// The unlocked key of a channel, for one key version (the newest by default).
// You only have a key for the versions that were locked for you.
async function keyOf(channel, version = channel && channel.key_version) {
  const locked = channel && channel.keys && channel.keys['v' + version];
  if (!locked) return null;
  if (!keyCache.has(locked)) {
    keyCache.set(locked, await TVCrypto.unwrapKey(locked, privateKey));
  }
  return keyCache.get(locked);
}

// What keys.js needs to work out which locked keys to send
const keyTools = { publicKeys, keyOf };

// The team description is encrypted with the team key
async function descriptionOf(channel) {
  if (!channel || !channel.desc_ct) return '';
  try {
    const key = await keyOf(channel, channel.desc_kv);
    return key ? await TVCrypto.decryptText(key, channel.desc_iv, channel.desc_ct) : '';
  } catch (error) {
    return '';
  }
}
