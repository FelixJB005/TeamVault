// The Members tab: people and roles, teams, and invite links.

/* ---------- People ---------- */

// Change somebody's role. A new admin needs the keys of every team, and keys.js works out what to send.
async function changeRole(user, role) {
  const community = currentCommunity();
  try {
    const newMembers = community.members.map((m) => (m.user === user ? { ...m, role } : m));
    const keys = await TVKeys.forCommunity(community, newMembers, {}, keyTools);
    const data = await perform('set_role', { community: community.id, user, role, keys: JSON.stringify(keys) });
    if (data.ok) toast(user + ' is now ' + ROLE_LABELS[role].toLowerCase() + '.');
    return data;
  } catch (error) {
    toast(error.message, true);
    return { ok: false };
  }
}

// Remove somebody. Every channel they could read gets a new key that they never receive.
async function removeMember(user) {
  const yes = await askConfirm('Remove ' + user + '?', user + ' will lose access to this community and all its teams. Every channel they could read gets a new key, so they cannot read anything new.', 'Remove');
  if (!yes) return;
  const community = currentCommunity();
  try {
    const keys = await TVKeys.forCommunity(community, community.members.filter((m) => m.user !== user), {}, keyTools);
    const data = await perform('remove_member', { community: community.id, user, keys: JSON.stringify(keys) });
    if (data.ok) {
      toast(user + ' was removed.');
      await sync();
    }
  } catch (error) {
    toast(error.message, true);
  }
}

function makeMemberCard(member) {
  const info = make('div', 'card-info');
  info.append(make('div', 'card-name', member.user + (member.user === me ? ' (you)' : '')));
  const card = make('div', 'card');
  card.append(makeAvatar(member.user), info);

  if (isAdmin()) {
    const select = make('select');
    select.setAttribute('aria-label', 'Role of ' + member.user);
    for (const role of ['member', 'subadmin', 'admin']) {
      const option = make('option', '', ROLE_LABELS[role]);
      option.value = role;
      option.selected = member.role === role;
      select.append(option);
    }
    select.addEventListener('change', async () => {
      await changeRole(member.user, select.value);
      await sync();
      drawMembersPane();
    });
    card.append(select);
    if (member.user !== me) {
      const remove = make('button', 'danger', 'Remove');
      remove.type = 'button';
      remove.addEventListener('click', () => removeMember(member.user));
      card.append(remove);
    }
  } else {
    card.append(makeBadge(member.role));
  }
  return card;
}

/* ---------- Teams ---------- */

function makeTeamCard(team, description) {
  const info = make('div', 'card-info');
  info.append(make('div', 'card-name', team.name));
  if (description) info.append(make('div', 'card-sub', description));

  const stack = make('div', 'avatar-stack');
  for (const name of team.members.slice(0, 6)) stack.append(makeAvatar(name, 'small'));
  const total = team.members.length;
  info.append(stack, make('div', 'card-sub', total + (total === 1 ? ' person' : ' people') + (total > 6 ? ' (' + (total - 6) + ' not shown)' : '')));

  const actions = make('div', 'file-actions');
  const open = make('button', 'secondary', 'Open');
  open.type = 'button';
  open.addEventListener('click', () => openChannel(currentCommunityId, team.id, 'chat'));
  actions.append(open);
  if (canManage()) {
    const edit = make('button', 'secondary', 'Edit');
    edit.type = 'button';
    edit.addEventListener('click', () => openTeamDialog(team));
    actions.append(edit);
  }

  const card = make('div', 'card');
  card.append(make('div', 'team-icon', '\u25C6'), info, actions);
  return card;
}

/* ---------- Invite links ---------- */

// The link: login.html?invite=ID#SECRET . The SECRET (after the #) never reaches the server.
async function createInviteLink() {
  const community = currentCommunity();
  const general = community.channels.find((c) => c.type === 'general');
  try {
    // Lock every version of the General key with a new secret
    const keys = {};
    for (let version = 1; version <= general.key_version; version++) {
      keys['v' + version] = await keyOf(general, version);
      if (!keys['v' + version]) throw new Error('You do not have the key for this community.');
    }
    const secret = TVCrypto.newInviteSecret();
    const sealed = await TVCrypto.sealKeysForInvite(secret, keys);
    const data = await perform('create_invite', { community: community.id, iv: sealed.iv, ct: sealed.ct });
    if (!data.ok) return;
    $('inviteLink').value = new URL('login.html', window.location.href).href + '?invite=' + data.invite + '#' + secret;
    $('inviteResult').hidden = false;
    drawInvites();
  } catch (error) {
    toast(error.message, true);
  }
}

async function drawInvites() {
  const box = $('inviteList');
  if (!canManage()) return;
  const data = await TVApi.get('list_invites', { community: currentCommunityId });
  if (!data.ok) return;
  box.replaceChildren();
  for (const invite of data.invites) {
    const info = make('div', 'card-info');
    info.append(make('div', 'card-name', 'Invite from ' + (invite.by === me ? 'you' : invite.by)), make('div', 'card-sub', 'Created ' + formatDate(invite.at) + ' \u00B7 expires ' + formatDate(invite.expires)));
    const revoke = make('button', 'danger', 'Revoke');
    revoke.type = 'button';
    revoke.addEventListener('click', async () => {
      const result = await perform('revoke_invite', { community: currentCommunityId, invite: invite.id });
      if (result.ok) drawInvites();
    });
    const card = make('div', 'card');
    card.append(info, revoke);
    box.append(card);
  }
  if (data.invites.length === 0) box.append(make('p', 'hint', 'No open invite links.'));
}

$('createInvite').addEventListener('click', createInviteLink);
$('copyInvite').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText($('inviteLink').value);
    toast('Link copied.');
  } catch (error) {
    $('inviteLink').select();
    toast('Press Ctrl+C to copy the link.');
  }
});

/* ---------- The whole tab ---------- */

async function drawMembersPane() {
  const community = currentCommunity();
  if (!community) return;
  const openId = community.id;

  const count = community.members.length;
  $('memberCount').textContent = count + (count === 1 ? ' person' : ' people') + ' in ' + community.name;
  $('memberList').replaceChildren(...community.members.map(makeMemberCard));

  // Team descriptions are encrypted, so they are decrypted first
  const teams = community.channels.filter((c) => c.type === 'team');
  $('teamCount').textContent = teams.length === 0 ? 'No teams you can see yet' : teams.length + (teams.length === 1 ? ' team' : ' teams');
  const cards = [];
  for (const team of teams) cards.push(makeTeamCard(team, await descriptionOf(team)));
  if (currentCommunityId !== openId) return;
  if (cards.length === 0) cards.push(make('p', 'hint', canManage() ? 'Create a team to give a group of people their own chat and files.' : 'You are not in a team yet.'));
  $('teamCards').replaceChildren(...cards);

  $('inviteResult').hidden = true;
  drawInvites();
}
