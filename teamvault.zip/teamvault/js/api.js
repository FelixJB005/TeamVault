// Talking to the server. Requests go to auth.php or api.php as   file?action=NAME
//  - reading is a GET, changing is a POST
//  - every POST carries the anti-forgery token in the X-CSRF-Token header (the server gave it to us)
// Every function returns the server's JSON answer: { ok: true, ... } or { ok: false, error: '...' }.

const TVApi = (() => {
  let csrf = '';
  const OFFLINE = { ok: false, error: 'Could not reach the server. Check your connection and try again.' };

  async function send(script, action, method, fields, retry = true) {
    const query = new URLSearchParams(method === 'GET' ? { action, ...fields } : { action });
    const options = { method, headers: {} };
    if (method === 'POST') {
      options.headers['X-CSRF-Token'] = csrf;
      options.body = fields instanceof FormData ? fields : new URLSearchParams(fields);
    }
    let data;
    try {
      data = await (await fetch(script + '?' + query, options)).json();
    } catch (error) {
      return OFFLINE;
    }
    if (typeof data.csrf === 'string') csrf = data.csrf;                    // a new token
    if (data.ok === false && data.csrf === true && retry) {                 // the token was out of date: get a new one and try once more
      await start();
      return send(script, action, method, fields, false);
    }
    if (data.signin && script === 'api.php') window.location.href = 'login.html';
    return data;
  }

  // Who is signed in, and a fresh anti-forgery token
  const start = () => send('auth.php', 'me', 'GET', {}, false);

  const auth = (action, fields = {}) => send('auth.php', action, 'POST', fields);
  const get = (action, params = {}) => send('api.php', action, 'GET', params);
  const post = (action, fields = {}) => send('api.php', action, 'POST', fields);

  // A file upload with a progress percentage (fetch cannot report upload progress)
  function upload(action, form, onProgress) {
    return new Promise((resolve) => {
      const request = new XMLHttpRequest();
      request.open('POST', 'api.php?action=' + action);
      request.setRequestHeader('X-CSRF-Token', csrf);
      request.responseType = 'json';
      request.upload.onprogress = (event) => {
        if (event.lengthComputable) onProgress(Math.round((event.loaded / event.total) * 100));
      };
      request.onload = () => resolve(request.response || { ok: false, error: 'The server did not accept the upload.' });
      request.onerror = () => resolve(OFFLINE);
      request.send(form);
    });
  }

  // For downloads the answer is the file itself, so the raw response is returned
  const raw = (action, params) => fetch('api.php?' + new URLSearchParams({ action, ...params }));

  return { start, auth, get, post, upload, raw };
})();
