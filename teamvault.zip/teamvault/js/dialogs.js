// Dialogs: ask before a risky action, create a community, add people, create or edit a team,
// join with an invite, settings, and "how encryption works".

/* ---------- Ask first ---------- */

let confirmResolve = null;

// Shows a question. Returns a promise that gives true (OK) or false (Cancel).
function askConfirm(title, text, button = 'OK') {
  $('confirmTitle').textContent = title;
  $('confirmText').textContent = text;
  $('confirmYes').textContent = button;
  $('confirmDialog').showModal();
  return new Promise((resolve) => { confirmResolve = resolve; });
}

function answerConfirm(yes) {
  $('confirmDialog').close();
  if (confirmResolve) confirmResolve(yes);
  confirmResolve = null;
}
$('confirmYes').addEventListener('click', () => answerConfirm(true));
$('confirmNo').addEventListener('click', () => answerConfirm(false));
$('confirmDialog').addEventListener('cancel', () => answerConfirm(false));      // the Escape key

/* ---------- Lists of people with checkboxes (and a role for each) ---------- */

// roles: a list like ['member', 'subadmin'] shows a role menu next to each person, or null for no menu
// locked: people who are always included, like { alice: 'Admin' }. They are shown ticked and cannot be changed.
function fillChecklist(box, names, checked, emptyText, roles, locked = {}) {
  box.replaceChildren();
  if (names.every((name) => name in locked)) box.append(make('p', 'hint', emptyText));
  for (const name of names) {
    const isLocked = name in locked;
    const checkbox = make('input');
    checkbox.type = 'checkbox';
    checkbox.value = name;
    checkbox.checked = isLocked || checked.includes(name);
    checkbox.disabled = isLocked;
    const label = make('label', 'check' + (isLocked ? ' locked' : ''));
    label.append(checkbox, makeAvatar(name, 'small'), make('span', 'item-name', name));
    if (isLocked) label.append(make('span', 'check-note', locked[name]));

    const row = make('div', 'check-row');
    row.append(label);
    if (roles) {
      const select = make('select');
      select.setAttribute('aria-label', 'Role of ' + name);
      for (const role of roles) {
        const option = make('option', '', ROLE_LABELS[role]);
        option.value = role;
        select.append(option);
      }
      row.append(select);
    }
    box.append(row);
  }
}

// The people that are ticked, with the role chosen for each: [{ name, role }]
// (people who are always included are left out, the server adds them itself)
function checkedPeople(box) {
  return [...box.querySelectorAll('.check-row')]
    .filter((row) => row.querySelector('input').checked && !row.querySelector('input').disabled)
    .map((row) => ({
      name: row.querySelector('input').value,
      role: row.querySelector('select') ? row.querySelector('select').value : 'member',
    }));
}

/* ---------- Create a community ---------- */

function openCreateDialog() {
  $('communityName').value = '';
  $('createError').textContent = '';
  fillChecklist($('memberChoices'), people.filter((name) => name !== me), [], 'Nobody else has registered yet.', ['member', 'subadmin', 'admin']);
  $('createDialog').showModal();
  $('communityName').focus();
}

$('newCommunity').addEventListener('click', openCreateDialog);
$('emptyCreate').addEventListener('click', openCreateDialog);
$('cancelCreate').addEventListener('click', () => $('createDialog').close());

$('createForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const name = $('communityName').value.trim();
  if (!name) {
    $('createError').textContent = 'Enter a community name.';
    return;
  }
  const chosen = checkedPeople($('memberChoices'));
  const names = chosen.map((p) => p.name);

  let keys;
  try {
    // A new key for the General channel, locked once for you and once for each person you add
    keys = (await TVKeys.forNewChannel([me, ...names], keyTools)).payload;
  } catch (error) {
    $('createError').textContent = error.message;
    return;
  }
  const data = await TVApi.post('create_community', {
    name,
    members: JSON.stringify(names),
    roles: JSON.stringify(Object.fromEntries(chosen.map((p) => [p.name, p.role]))),
    keys: JSON.stringify({ general: keys }),
  });
  if (!data.ok) {
    $('createError').textContent = data.error;
    return;
  }
  $('createDialog').close();
  await sync();
  openChannel(data.community.id, 'general', 'overview');
  toast('Community created.');
});

/* ---------- Add people to the open community ---------- */

function openAddDialog() {
  $('addError').textContent = '';
  const inside = currentCommunity().members.map((m) => m.user);
  // Admins can add members, sub-admins and admins. Sub-admins can only add members.
  $('addNote').textContent = isAdmin() ? 'Choose a role for each person.' : 'People you add join as members.';
  fillChecklist($('addChoices'), people.filter((name) => !inside.includes(name)), [], 'Everyone who has registered is already in this community. To bring in someone new, use an invite link.', isAdmin() ? ['member', 'subadmin', 'admin'] : null);
  $('addDialog').showModal();
}

$('addPeople').addEventListener('click', openAddDialog);
$('menuAddPeople').addEventListener('click', openAddDialog);
$('cancelAdd').addEventListener('click', () => $('addDialog').close());

$('addForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const chosen = checkedPeople($('addChoices'));
  const community = currentCommunity();

  // People who should be admins are added as members first, then promoted (that step needs the team keys)
  const firstRole = (p) => (p.role === 'admin' ? 'member' : p.role);
  let keys;
  try {
    const newMembers = [...community.members, ...chosen.map((p) => ({ user: p.name, role: firstRole(p) }))];
    keys = await TVKeys.forCommunity(community, newMembers, {}, keyTools);
  } catch (error) {
    $('addError').textContent = error.message;
    return;
  }
  const data = await TVApi.post('add_members', {
    community: community.id,
    members: JSON.stringify(chosen.map((p) => p.name)),
    roles: JSON.stringify(Object.fromEntries(chosen.map((p) => [p.name, firstRole(p)]))),
    keys: JSON.stringify(keys),
  });
  if (!data.ok) {
    $('addError').textContent = data.error;
    return;
  }
  await sync();
  for (const person of chosen.filter((p) => p.role === 'admin')) await changeRole(person.name, 'admin');
  $('addDialog').close();
  await sync();
  toast(chosen.length === 1 ? chosen[0].name + ' was added.' : chosen.length + ' people were added.');
});

/* ---------- Create or edit a team ---------- */

// Pass a team (channel) to edit it, or nothing to create a new team
async function openTeamDialog(team) {
  editingTeam = team || null;
  $('teamTitle').textContent = team ? 'Edit team' : 'New team';
  $('teamName').value = team ? team.name : '';
  $('teamDescription').value = team ? await descriptionOf(team) : '';
  $('teamError').textContent = '';

  // Admins can always read every team, and a sub-admin stays in the teams they create or edit.
  // They are shown at the top as always included, then everyone else can be ticked.
  const community = currentCommunity();
  const locked = {};
  for (const member of community.members) {
    if (member.role === 'admin') locked[member.user] = member.user === me ? 'Admin (you)' : 'Admin';
  }
  if (!(me in locked)) locked[me] = 'You';
  const others = community.members.map((m) => m.user).filter((name) => !(name in locked));
  fillChecklist($('teamChoices'), [...Object.keys(locked), ...others], team ? team.explicit : [], 'Add more people to the community to choose them here.', null, locked);
  $('teamNote').textContent = isAdmin()
    ? 'Admins are always in every team. A person can be in as many teams as you like.'
    : 'Admins are always in every team, and you stay in the teams you create or edit.';

  $('teamDialog').showModal();
  $('teamName').focus();
}

$('newTeam').addEventListener('click', () => openTeamDialog(null));
$('sideNewTeam').addEventListener('click', () => openTeamDialog(null));
$('menuNewTeam').addEventListener('click', () => openTeamDialog(null));
$('menuEditTeam').addEventListener('click', () => openTeamDialog(currentChannel()));
$('cancelTeam').addEventListener('click', () => $('teamDialog').close());

$('teamForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const name = $('teamName').value.trim();
  if (!name) {
    $('teamError').textContent = 'Enter a team name.';
    return;
  }
  const description = $('teamDescription').value.trim();
  const community = currentCommunity();
  const picked = checkedPeople($('teamChoices')).map((p) => p.name);
  if (myRole() === 'subadmin' && !picked.includes(me)) picked.push(me);       // a sub-admin stays in their own teams

  const fields = { community: community.id, name, members: JSON.stringify(picked) };
  let teamId;
  try {
    let key;
    let version;
    if (editingTeam) {
      // An existing team keeps its keys. If somebody lost access it gets a new key version.
      teamId = editingTeam.id;
      const readers = TVKeys.readersOf(editingTeam, community.members, picked);
      const change = await TVKeys.forChange(editingTeam, readers, keyTools);
      key = change.newKey || await keyOf(editingTeam);
      version = change.version;
      fields.channel = teamId;
      fields.keys = JSON.stringify({ [teamId]: change.payload });
    } else {
      // A new team: the page makes its id and its first key, locked for every reader
      teamId = randomId();
      const readers = TVKeys.readersOf({ type: 'team' }, community.members, picked);
      const made = await TVKeys.forNewChannel(readers, keyTools);
      key = made.key;
      version = 1;
      fields.channel = teamId;
      fields.keys = JSON.stringify({ [teamId]: made.payload });
    }
    if (!key) throw new Error('You do not have the key for this team.');
    const encrypted = description ? await TVCrypto.encryptText(key, description) : { iv: '', ct: '' };
    fields.desc_iv = encrypted.iv;
    fields.desc_ct = encrypted.ct;
    fields.desc_kv = version;
  } catch (error) {
    $('teamError').textContent = error.message;
    return;
  }

  const data = await TVApi.post(editingTeam ? 'update_team' : 'create_team', fields);
  if (!data.ok) {
    $('teamError').textContent = data.error;
    return;
  }
  const wasEditing = Boolean(editingTeam);
  $('teamDialog').close();
  await sync();
  openChannel(community.id, teamId, wasEditing ? null : 'chat');
  toast(wasEditing ? 'Team saved.' : 'Team created.');
});

/* ---------- Join with an invite link ---------- */

let pendingInvite = null;

// If the person came from an invite link, ask whether to join
async function offerInvite() {
  const saved = sessionStorage.getItem('tv_invite');
  if (!saved) return;
  pendingInvite = JSON.parse(saved);
  const info = await TVApi.get('invite_info', { invite: pendingInvite.id });
  if (!info.ok) {
    sessionStorage.removeItem('tv_invite');
    toast(info.error, true);
    return;
  }
  if (info.already_member) {
    sessionStorage.removeItem('tv_invite');
    toast('You are already in ' + info.community + '.');
    openChannel(info.community_id, 'general', 'overview');
    return;
  }
  pendingInvite.info = info;
  $('joinText').textContent = info.by + ' invited you to join "' + info.community + '". You will become a member and can read the General channel.';
  $('joinError').textContent = '';
  $('joinDialog').showModal();
}

$('joinCancel').addEventListener('click', () => {
  sessionStorage.removeItem('tv_invite');
  $('joinDialog').close();
});

$('joinConfirm').addEventListener('click', async () => {
  const { id, secret, info } = pendingInvite;
  try {
    // The secret from the link unlocks the community keys. They are locked again for your own public key.
    const keys = await TVCrypto.openInviteKeys(secret, info.iv, info.ct);
    const mine = {};
    for (const name in keys) mine[name] = await TVCrypto.wrapKey(keys[name], publicKeys[me]);
    const data = await TVApi.post('accept_invite', { invite: id, keys: JSON.stringify({ general: { [me]: mine } }) });
    if (!data.ok) throw new Error(data.error);
    sessionStorage.removeItem('tv_invite');
    $('joinDialog').close();
    await sync();
    openChannel(data.community_id, 'general', 'overview');
    toast('You joined ' + info.community + '.');
  } catch (error) {
    $('joinError').textContent = error instanceof DOMException ? 'This invite link is damaged. Ask for a new one.' : error.message;
  }
});

/* ---------- How encryption works ---------- */

$('learnEncryption').addEventListener('click', () => $('encryptionDialog').showModal());
$('closeEncryption').addEventListener('click', () => $('encryptionDialog').close());

/* ---------- Settings ---------- */

const passwordProblem = (password, confirm) =>
  password.length < 8 ? 'Password must be at least 8 characters.' : password !== confirm ? 'Passwords do not match.' : '';

function drawThemeChoices() {
  $('themeChoices').querySelectorAll('button').forEach((button) => {
    button.classList.toggle('selected', button.dataset.theme === TVTheme.get());
  });
}

function drawSwatches() {
  const box = $('colorChoices');
  box.replaceChildren();
  COLORS.forEach((color, index) => {
    const button = make('button', 'swatch' + (color === settings.color ? ' selected' : ''));
    button.type = 'button';
    button.style.background = color;
    button.setAttribute('aria-label', 'Profile color ' + (index + 1));
    button.addEventListener('click', () => {
      settings.color = color;
      localStorage.setItem('tv_color', color);
      drawSwatches();
      refreshAvatars();
    });
    box.append(button);
  });
}

$('openSettings').addEventListener('click', () => {
  drawThemeChoices();
  drawSwatches();
  $('compactToggle').checked = settings.compact;
  for (const id of ['passwordMessage', 'recoveryMessage']) $(id).textContent = '';
  $('passwordForm').reset();
  $('recoveryForm').reset();
  $('recoveryResult').hidden = true;
  $('settingsDialog').showModal();
});
$('closeSettings').addEventListener('click', () => {
  $('recoveryResult').hidden = true;
  $('newCode').textContent = '';
  $('settingsDialog').close();
});

$('themeChoices').addEventListener('click', (event) => {
  if (event.target.dataset.theme) {
    TVTheme.set(event.target.dataset.theme);
    drawThemeChoices();
    drawThemeButton();
  }
});

$('compactToggle').addEventListener('change', (event) => {
  settings.compact = event.target.checked;
  localStorage.setItem('tv_compact', settings.compact ? '1' : '0');
  document.body.classList.toggle('compact', settings.compact);
});

// Change password: the private key is locked again with the new password. Your keys stay the same.
$('passwordForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const message = $('passwordMessage');
  const current = $('currentPassword').value;
  const next = $('newPassword').value;
  const problem = !current ? 'Enter your current password.' : passwordProblem(next, $('confirmNewPassword').value);
  message.classList.remove('ok');
  if (problem) {
    message.textContent = problem;
    return;
  }
  const data = await TVApi.auth('change_password', {
    current: await TVCrypto.loginSecret(me, current),
    new: await TVCrypto.loginSecret(me, next),
    wrapped_private_key: await TVCrypto.lockPrivateKey(sessionStorage.getItem('tv_private'), next),
  });
  message.textContent = data.ok ? 'Your password was changed.' : data.error;
  message.classList.toggle('ok', data.ok);
  if (data.ok) event.target.reset();
});

// A new recovery code replaces the old one
$('recoveryForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const message = $('recoveryMessage');
  const password = $('recoveryPassword').value;
  message.classList.remove('ok');
  if (!password) {
    message.textContent = 'Enter your password.';
    return;
  }
  const code = TVCrypto.newRecoveryCode();
  const recovery = await TVCrypto.makeRecovery(me, sessionStorage.getItem('tv_private'), code);
  const data = await TVApi.auth('new_recovery', {
    current: await TVCrypto.loginSecret(me, password),
    recovery_proof: recovery.proof,
    recovery_private_key: recovery.sealedPrivateKey,
  });
  if (!data.ok) {
    message.textContent = data.error;
    return;
  }
  message.textContent = 'Save this code now. It is not shown again, and the old code no longer works.';
  message.classList.add('ok');
  $('newCode').textContent = code;
  $('recoveryResult').hidden = false;
  event.target.reset();
});

$('copyNewCode').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText($('newCode').textContent);
    toast('Recovery code copied.');
  } catch (error) {
    toast('Select the code and copy it.');
  }
});
