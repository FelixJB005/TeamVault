// The sign in page: sign in, create an account, recovery code, forgot password, invite links.
// All encryption happens here in the browser (see crypto.js). The server only gets proofs and locked keys.

const $ = (id) => document.getElementById(id);
const VIEWS = ['loginView', 'registerView', 'codeView', 'forgotView'];
const FIRST_FIELD = { loginView: 'loginUsername', registerView: 'regUsername', forgotView: 'forgotUsername' };
let recoveryCode = '';
let registeredName = '';

function showView(name) {
  VIEWS.forEach((view) => { $(view).hidden = view !== name; });
  if (FIRST_FIELD[name]) $(FIRST_FIELD[name]).focus();
}

// Disable a button while the browser does the encryption work (it takes a moment)
function setBusy(form, busy, label) {
  const button = form.querySelector('.submit');
  button.disabled = busy;
  button.textContent = busy ? 'Please wait...' : label;
}

function say(id, text, good) {
  $(id).textContent = text;
  $(id).classList.toggle('ok', Boolean(good));
}

const passwordProblem = (password, confirm) =>
  password.length < 8 ? 'Password must be at least 8 characters.' : password !== confirm ? 'Passwords do not match.' : '';

/* ---------- Switching views, buttons ---------- */

[['showRegister', 'registerView'], ['showLogin', 'loginView'], ['showForgot', 'forgotView'], ['forgotBack', 'loginView']].forEach(([link, view]) => {
  $(link).addEventListener('click', (event) => {
    event.preventDefault();
    showView(view);
  });
});

document.querySelectorAll('.toggle').forEach((button) => {
  button.addEventListener('click', () => {
    const input = $(button.dataset.target);
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    button.textContent = show ? 'Hide' : 'Show';
    button.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  });
});

$('themeButton').addEventListener('click', TVTheme.toggle);

/* ---------- Sign in ---------- */

$('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const username = $('loginUsername').value.trim();
  const password = $('loginPassword').value;
  if (!username || !password) {
    say('loginError', 'Enter both your username and password.');
    return;
  }
  const form = event.target;
  setBusy(form, true, 'Sign in');
  try {
    // The server gets a login secret made from the password, never the password itself
    const data = await TVApi.auth('login', { username, password: await TVCrypto.loginSecret(username, password) });
    if (!data.ok) {
      say('loginError', data.error);
      return;
    }
    // Unlock your private key with the password and keep it for this browser tab
    sessionStorage.setItem('tv_private', await TVCrypto.unlockPrivateKey(data.wrapped_private_key, password));
    window.location.href = 'main.html';
  } catch (error) {
    say('loginError', 'Could not unlock your encryption keys.');
  } finally {
    setBusy(form, false, 'Sign in');
  }
});

/* ---------- Create an account ---------- */

$('registerForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const username = $('regUsername').value.trim();
  const email = $('regEmail').value.trim();
  const password = $('regPassword').value;
  let problem = '';
  if (!username || !email || !password) problem = 'Fill in all the fields.';
  else if (!$('regEmail').checkValidity()) problem = 'Enter a valid email address.';
  else problem = passwordProblem(password, $('regConfirm').value);
  if (problem) {
    say('registerError', problem);
    return;
  }

  const form = event.target;
  setBusy(form, true, 'Create account');
  try {
    // Make the encryption keys here. The private key is locked with the password, and again with a recovery code.
    const keys = await TVCrypto.createAccountKeys();
    const code = TVCrypto.newRecoveryCode();
    const recovery = await TVCrypto.makeRecovery(username, keys.privateKey, code);
    const data = await TVApi.auth('register', {
      username,
      email,
      password: await TVCrypto.loginSecret(username, password),
      public_key: keys.publicKey,
      wrapped_private_key: await TVCrypto.lockPrivateKey(keys.privateKey, password),
      recovery_proof: recovery.proof,
      recovery_private_key: recovery.sealedPrivateKey,
    });
    if (!data.ok) {
      say('registerError', data.error);
      return;
    }
    form.reset();
    say('registerError', '');
    registeredName = username;
    recoveryCode = code;
    $('recoveryCode').textContent = code;
    $('savedCheck').checked = false;
    $('continueButton').disabled = true;
    showView('codeView');
  } catch (error) {
    say('registerError', 'Could not create your encryption keys.');
  } finally {
    setBusy(form, false, 'Create account');
  }
});

/* ---------- The recovery code screen ---------- */

$('copyCode').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(recoveryCode);
    $('copyCode').textContent = 'Copied';
  } catch (error) {
    $('copyCode').textContent = 'Select the code and copy it';
  }
});

$('downloadCode').addEventListener('click', () => {
  const text = 'TeamVault recovery code for ' + registeredName + '\n\n' + recoveryCode + '\n\nKeep this somewhere safe. If you forget your password, this code is the only way to get your data back.\n';
  const link = document.createElement('a');
  link.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' }));
  link.download = 'teamvault-recovery-code.txt';
  document.body.append(link);
  link.click();
  link.remove();
});

$('savedCheck').addEventListener('change', () => { $('continueButton').disabled = !$('savedCheck').checked; });

$('continueButton').addEventListener('click', () => {
  recoveryCode = '';
  $('recoveryCode').textContent = '';
  $('loginUsername').value = registeredName;
  say('loginError', 'Account created. Sign in to continue.', true);
  showView('loginView');
  $('loginPassword').focus();
});

/* ---------- Forgot password ---------- */

$('forgotForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const username = $('forgotUsername').value.trim();
  const code = $('forgotCode').value;
  const password = $('forgotPassword').value;
  let problem = '';
  if (!username || !code.trim() || !password) problem = 'Fill in all the fields.';
  else problem = passwordProblem(password, $('forgotConfirm').value);
  if (problem) {
    say('forgotError', problem);
    return;
  }

  const form = event.target;
  setBusy(form, true, 'Reset password');
  try {
    // Step 1: prove that you have the recovery code, and get your locked private key back
    const proof = await TVCrypto.recoveryProof(username, code);
    const start = await TVApi.auth('recovery_start', { username, recovery_proof: proof });
    if (!start.ok) {
      say('forgotError', start.error);
      return;
    }
    // Step 2: unlock the private key with the code, lock it again with the new password
    const privateKey = await TVCrypto.unlockWithRecovery(start.recovery_private_key, code);
    const finish = await TVApi.auth('recovery_finish', {
      username,
      recovery_proof: proof,
      new: await TVCrypto.loginSecret(username, password),
      wrapped_private_key: await TVCrypto.lockPrivateKey(privateKey, password),
    });
    if (!finish.ok) {
      say('forgotError', finish.error);
      return;
    }
    form.reset();
    say('forgotError', '');
    $('loginUsername').value = username;
    say('loginError', 'Your password was changed. Sign in with the new password.', true);
    showView('loginView');
  } catch (error) {
    say('forgotError', 'That recovery code could not unlock your keys.');
  } finally {
    setBusy(form, false, 'Reset password');
  }
});

/* ---------- Start ---------- */

// An invite link looks like  login.html?invite=ID#SECRET . Remember it for after sign in.
// The SECRET (after the #) never leaves this browser. It unlocks the community keys.
(function rememberInvite() {
  const id = new URLSearchParams(window.location.search).get('invite');
  const secret = window.location.hash.slice(1);
  if (id && secret) {
    sessionStorage.setItem('tv_invite', JSON.stringify({ id, secret }));
    history.replaceState(null, '', window.location.pathname);
  }
  $('inviteBanner').hidden = !sessionStorage.getItem('tv_invite');
})();

if (!window.crypto || !window.crypto.subtle) {
  say('loginError', 'Encryption needs https:// or http://localhost. Open this page with a secure address.');
}

// Get the anti-forgery token. If you are already signed in and your keys are still in this tab, go straight to the app.
TVApi.start().then((data) => {
  if (data.username && sessionStorage.getItem('tv_private')) window.location.href = 'main.html';
  else showView('loginView');
});
