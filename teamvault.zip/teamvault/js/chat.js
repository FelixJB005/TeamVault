// Chat: showing messages (decrypted here) and sending them (encrypted here).

function makeMessage(message, text) {
  const mine = message.user === me;
  const meta = make('div', 'meta');
  meta.append(make('strong', '', mine ? 'You' : message.user), make('time', '', formatTime(message.at)));

  const bubble = make('div', 'bubble');
  bubble.append(meta, make('p', '', text));

  const row = make('div', 'message' + (mine ? ' mine' : ''));
  row.append(makeAvatar(message.user, 'small'), bubble);
  return row;
}

// Decrypt one message with the key version it was written with. Shows a notice if that is not possible.
async function readMessage(channel, message) {
  try {
    const key = await keyOf(channel, message.kv);
    if (!key) return '[You do not have the key for this message]';
    return await TVCrypto.decryptText(key, message.iv, message.ct);
  } catch (error) {
    return '[This message could not be decrypted]';
  }
}

// Add new messages (from the server) to the open chat
async function addMessages(list) {
  const openCommunity = currentCommunityId;
  const openChannelId = currentChannelId;
  const channel = currentChannel();
  const box = $('messages');
  const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 80;

  for (const message of list) {
    if (message.id <= lastMessageId) continue;                    // already shown
    const text = await readMessage(channel, message);
    if (openCommunity !== currentCommunityId || openChannelId !== currentChannelId) return;   // something else was opened meanwhile
    box.append(makeMessage(message, text));
    lastMessageId = message.id;
  }
  $('noMessages').hidden = lastMessageId > 0;
  if (list.length > 0 && (nearBottom || list.some((m) => m.user === me))) {
    box.scrollTop = box.scrollHeight;
  }
}

$('messageForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const input = $('messageInput');
  const text = input.value.trim();
  const channel = currentChannel();
  if (!text || !channel) return;

  input.value = '';
  try {
    const key = await keyOf(channel);
    if (!key) throw new Error('You do not have the key for this chat.');
    const encrypted = await TVCrypto.encryptText(key, text);
    const data = await TVApi.post('send_message', {
      community: currentCommunityId,
      channel: channel.id,
      kv: channel.key_version,
      iv: encrypted.iv,
      ct: encrypted.ct,
    });
    if (!data.ok) throw new Error(data.error);
    sync();
  } catch (error) {
    input.value = text;
    toast(error.message, true);
  }
});
