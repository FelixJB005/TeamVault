<?php
defined('TEAMVAULT') or exit;

// =====================================================================
//  TeamVault settings. This is the only PHP file you edit when you
//  move the site to a real server.
// =====================================================================

// Where the encrypted data is kept (users, communities, messages, files).
// On a real server use a folder OUTSIDE the public web folder, for example:
//   define('DATA_DIR', '/home/yourname/teamvault-data');
define('DATA_DIR', __DIR__ . '/data');

// The server's own key, used to encrypt everything stored in DATA_DIR ("encryption at rest").
// It is created automatically. Keep it in a DIFFERENT place from the data, outside the public web folder:
//   define('SERVER_KEY_FILE', '/home/yourname/teamvault-keys/server.key');
// Back it up. Without it the stored data cannot be read.
define('SERVER_KEY_FILE', DATA_DIR . '/server.key');

// Refuse to work over plain http:// (this is ignored on localhost).
define('FORCE_HTTPS', true);

// Biggest file people can upload, in MB. php.ini must allow at least this much
// (upload_max_filesize and post_max_size). Run check.php to see your limits.
define('MAX_FILE_MB', 95);
define('MAX_FILE_BYTES', (int) (MAX_FILE_MB * 1024 * 1024) + 4096);   // plus the small overhead of encryption

// How long an invite link works, in days.
define('INVITE_DAYS', 7);

// Too many wrong passwords from one username or computer locks it for a while.
define('LOGIN_MAX_FAILS', 5);
define('LOGIN_WINDOW_MINUTES', 15);
define('LOGIN_LOCK_MINUTES', 15);

// Show PHP errors on screen. Keep this false on a real server.
define('DEBUG', false);
