<?php
// TeamVault - the workspace backend (communities, teams, chat, files, invites).
// This file only lists the actions. The work is done in the files inside lib/.
//
// Every request is   api.php?action=NAME   with GET for reading and POST for changing.
// Every POST must carry the anti-forgery token in the X-CSRF-Token header.

define('TEAMVAULT', true);
require __DIR__ . '/config.php';
foreach (['core', 'store', 'limits', 'accounts', 'community', 'workspace', 'chat', 'invites'] as $part) {
    require __DIR__ . '/lib/' . $part . '.php';
}

dispatch([
    // reading
    'sync'          => ['act_sync',          'GET',  false],
    'users'         => ['act_users',         'GET',  false],
    'communities'   => ['act_communities',   'GET',  false],
    'overview'      => ['act_overview',      'GET',  false],
    'activity'      => ['act_activity',      'GET',  false],
    'messages'      => ['act_messages',      'GET',  false],
    'files'         => ['act_files',         'GET',  false],
    'download_file' => ['act_download_file', 'GET',  false],
    'list_invites'  => ['act_list_invites',  'GET',  false],
    'invite_info'   => ['act_invite_info',   'GET',  false],
    // changing
    'create_community' => ['act_create_community', 'POST', false],
    'add_members'      => ['act_add_members',      'POST', false],
    'set_role'         => ['act_set_role',         'POST', false],
    'remove_member'    => ['act_remove_member',    'POST', false],
    'create_team'      => ['act_create_team',      'POST', false],
    'update_team'      => ['act_update_team',      'POST', false],
    'send_message'     => ['act_send_message',     'POST', false],
    'upload_file'      => ['act_upload_file',      'POST', false],
    'delete_file'      => ['act_delete_file',      'POST', false],
    'create_invite'    => ['act_create_invite',    'POST', false],
    'revoke_invite'    => ['act_revoke_invite',    'POST', false],
    'accept_invite'    => ['act_accept_invite',    'POST', false],
]);
