<?php
// TeamVault setup check.
// Open this page once after installing (https://your-site/check.php), fix anything marked red,
// and then DELETE this file from the server.

define('TEAMVAULT', true);
require __DIR__ . '/config.php';
require __DIR__ . '/lib/core.php';

function to_bytes($value) {
    $value = trim((string) $value);
    if ($value === '-1') {
        return PHP_INT_MAX;
    }
    $number = (float) $value;
    switch (strtolower(substr($value, -1))) {
        case 'g': return (int) ($number * 1073741824);
        case 'm': return (int) ($number * 1048576);
        case 'k': return (int) ($number * 1024);
        default:  return (int) $number;
    }
}

function inside_web_folder($path) {
    $root = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
    $real = realpath($path) ?: realpath(dirname($path)) ?: '';
    return $root !== '' && $real !== '' && strpos($real, $root) === 0;
}

// Can the data folder be written to?
function data_folder_problem() {
    if (!is_dir(DATA_DIR) && !@mkdir(DATA_DIR, 0750, true)) {
        return 'The folder ' . DATA_DIR . ' does not exist and could not be created.';
    }
    $test = DATA_DIR . '/.write-test';
    if (@file_put_contents($test, 'x') === false) {
        return 'PHP cannot write to ' . DATA_DIR . '. Change its permissions.';
    }
    @unlink($test);
    return '';
}

$need = (int) ceil(MAX_FILE_MB);
$problem = data_folder_problem();
$checks = [
    // [label, status ok|warn|bad, detail]
    ['PHP version 7.4 or newer', PHP_VERSION_ID >= 70400 ? 'ok' : 'bad', PHP_VERSION],
    ['OpenSSL extension (encrypts the stored data)', function_exists('openssl_encrypt') && in_array('aes-256-gcm', openssl_get_cipher_methods(), true) ? 'ok' : 'bad', 'needed'],
    ['Session support', function_exists('session_start') ? 'ok' : 'bad', 'needed'],
    ['JSON support', function_exists('json_encode') ? 'ok' : 'bad', 'needed'],
    ['Secure connection (https)', is_https() ? 'ok' : (is_local() ? 'warn' : 'bad'), is_https() ? 'yes' : (is_local() ? 'not needed on localhost' : 'turn on https: the browser encryption only works on secure pages')],
    ['Data folder can be written to', $problem === '' ? 'ok' : 'bad', $problem === '' ? DATA_DIR : $problem],
    ['Data folder is outside the public web folder', inside_web_folder(DATA_DIR) ? 'warn' : 'ok', inside_web_folder(DATA_DIR) ? 'move it and change DATA_DIR in config.php' : 'good'],
    ['Server key is outside the public web folder', inside_web_folder(SERVER_KEY_FILE) ? 'warn' : 'ok', inside_web_folder(SERVER_KEY_FILE) ? 'set SERVER_KEY_FILE in config.php to a path outside the web folder' : 'good'],
    ['File uploads are allowed', ini_get('file_uploads') ? 'ok' : 'bad', ''],
    ['upload_max_filesize is at least ' . $need . ' MB', to_bytes(ini_get('upload_max_filesize')) >= $need * 1048576 ? 'ok' : 'bad', 'now ' . ini_get('upload_max_filesize')],
    ['post_max_size is at least ' . ($need + 5) . ' MB', to_bytes(ini_get('post_max_size')) >= ($need + 5) * 1048576 ? 'ok' : 'bad', 'now ' . ini_get('post_max_size')],
    ['max_execution_time is 120 seconds or more', (int) ini_get('max_execution_time') === 0 || (int) ini_get('max_execution_time') >= 120 ? 'ok' : 'warn', 'now ' . ini_get('max_execution_time') . ' (slow connections need time for big uploads)'],
    ['memory_limit is 128 MB or more', to_bytes(ini_get('memory_limit')) >= 134217728 ? 'ok' : 'warn', 'now ' . ini_get('memory_limit')],
];
$icons = ['ok' => '&#10004;', 'warn' => '&#9888;', 'bad' => '&#10008;'];
$colors = ['ok' => '#15803d', 'warn' => '#b45309', 'bad' => '#dc2626'];
$bad = count(array_filter($checks, function ($c) { return $c[1] === 'bad'; }));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>TeamVault setup check</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 720px; margin: 30px auto; padding: 0 16px; line-height: 1.5; }
    table { width: 100%; border-collapse: collapse; }
    td { padding: 8px 6px; border-bottom: 1px solid #ddd; vertical-align: top; }
    td:first-child { width: 30px; font-weight: bold; }
    small { color: #555; }
    .box { padding: 12px 14px; border-radius: 8px; margin: 16px 0; }
  </style>
</head>
<body>
  <h1>TeamVault setup check</h1>
  <div class="box" style="background: <?= $bad ? '#fee2e2' : '#dcfce7' ?>">
    <?= $bad ? $bad . ' thing(s) need fixing before TeamVault will work well.' : 'Everything needed is in place.' ?>
  </div>
  <table>
    <?php foreach ($checks as $check): ?>
      <tr>
        <td style="color: <?= $colors[$check[1]] ?>"><?= $icons[$check[1]] ?></td>
        <td><?= htmlspecialchars($check[0]) ?><br><small><?= htmlspecialchars($check[2]) ?></small></td>
      </tr>
    <?php endforeach; ?>
  </table>
  <p><strong>Delete this file (check.php) from the server when you are done.</strong></p>
</body>
</html>
